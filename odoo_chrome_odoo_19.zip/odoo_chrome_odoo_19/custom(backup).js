// this function gets string from localStorage and converts it into JSON
function GetFromLocalStorage(key) {
	return JSON.parse(localStorage.getItem(key));
}
var myData = GetFromLocalStorage("added-items");
var object = {};
var json = '';
if(myData!=null)
{
	var base_url = myData['web.base.url'];
    var company = myData['user_companies'];
//    console.log(company['allowed_companies'])
    var companies = company['allowed_companies']
	var get_all_sale_url = base_url+'/sale/get_all_sale_details/';
	var get_all_receipt_url = base_url+'/receipt/get_all_receipt_details/';
	var get_all_payment_url = base_url+'/payment/get_all_payment_details/';
	var get_all_purchase_url = base_url+'/purchase/get_all_purchase_details/';
	var get_all_journal_url = base_url+'/journal/get_all_journal_details/';
	var get_sale_url = base_url+'/sale/get_sale_details/';
	var get_receipt_url = base_url+'/receipt/get_receipt_details/';
	var get_payment_url = base_url+'/payment/get_payment_details/';
	var get_purchase_url = base_url+'/purchase/get_purchase_details/';
	var get_journal_url = base_url+'/journal/get_journal_details/';
	var get_all_product_url = base_url+'/product/get_all_product_details/';
	var get_product_url = base_url+'/product/get_product_details/';
	var get_all_customer_url = base_url+'/customer/get_all_customer_details/';
	var get_customer_url = base_url+'/customer/get_customer_details/';
	var tally_sync_url = base_url+'/tally/tally_sync_done/';
	var session_id = '';
	chrome.storage.sync.get(['session_id'], function(result) {
		// console.log(result.session_id);
		session_id = result.session_id;
		// console.log(GetFromChromeLocalStorage(result.cookies));
	});
	chrome.storage.sync.get(['session_id'], function(result) {
		// console.log(result.session_id);
		session_id = result.session_id;
		// console.log(GetFromChromeLocalStorage(result.cookies));
	});
	var cookies = 'session_id='+session_id+';';
	object["jsonrpc"] = "2.0";
	json = JSON.stringify(object);
}
var entityMap = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
  "[": '&#91;',
  "]": '&#93;'
};

function escapeHtml (string) {
  return String(string).replace(/[&<>"']/g, function (s) {
    return entityMap[s];
  });
}
function call_all_sync($all_sync_id='',$sync_class='') {
  $(document).on("click",$all_sync_id, function (e) {
		if (document.querySelectorAll($sync_class)[0].getAttribute('data-send_another')=='true') 
		{
			Swal.fire({
             title: 'Please Wait..',
             allowOutsideClick: false
            });
            Swal.showLoading();	
		}
		else
		{
			$($sync_class).each(function(i,d){
				var sync_val_id = $(this).closest('tr').find($sync_class).attr('id');
				if (i==0) 
				{
					$('#'+sync_val_id).trigger('click');
				}

			});

		}
		e.preventDefault();
		$($sync_class).each(function(i,d){
			e.preventDefault();
			var sync_val_id = $(this).closest('tr').find($sync_class).attr('id');
			if ($('#'+sync_val_id).data('send_another')=='')
			{
				e.preventDefault();
				return false;
			}
			else
			{
				e.preventDefault();
				if($all_sync_id == '#sale_sync_all')
				{
					console.log('sale_+sync');
					if(i<20)
					{
						console.log('sale_+sync:: ', i);
						$('#'+sync_val_id).trigger('click');		
					}
					else
					{
						console.log('False');
						return false;
					}
				}
				// mohammad sync limit 
				else if($all_sync_id == '#purchase_sync_all')
				{
					console.log('purchase_+sync');
					if(i<20)
					{
						console.log('purchase_+sync:: ', i);
						$('#'+sync_val_id).trigger('click');		
					}
					else
					{
						console.log('False');
						return false;
					}
				}
				else
				{
					console.log('Else');
					$('#'+sync_val_id).trigger('click');	
				}
				
			}
		}).promise().done(function(){
			if (document.querySelectorAll($sync_class)[0].getAttribute('data-send_another')==true) 
			{
				Swal.close();	
			}
		});
	});
}

    $(document).ready(function()
    {
        var c_id = '';
        $.each(companies,function(index,data){
        {
            $("#company").append('<option value="'+data['id']+'">'+data['name']+ '</option>');
            if (c_id == data['current_company'])
            {
                $('#company option').attr('selected','selected');
            }
        }
        });
        //        $('#company').on('change', function (){
        //            Swal.fire({
        //                title: "Company Switched!",
        //                type: 'success',
        //                showConfirmButton:false,
        //                timer:1500
        //            });
        //            window.setTimeout(function(){location.reload()},1500)
        //        });
    });

function custom(ipAddress,ipAddressTally,ipAddress_api=null)
{

	$('#btn_logout').on('click', function () {
		localStorage.removeItem("added-items");
		chrome.storage.clear;
		Swal.fire({
			title: "Logout Success!",
			type: 'success',
			showConfirmButton:false,
			timer:1500
		});
		window.setTimeout(function(){location.reload()},1500)
	});
		//Sundry Debtors fetch All
	$('.fectAllSundry').on('click', function () {
		var display = 'Creditors';
		if ($(this).data('invoice_type') == 'Sale') 
		{
			display = 'Debtors';
		}
	 var ind = 0;
		document.write("<script src='jquery-3.3.1.min.js'></script>");
		document.write("<script src='custom.js'></script>");
		document.write("<script src='sweetalert2.js'></script>");
		document.write("<style>table {font-family: arial, sans-serif;border-collapse: collapse;width: 100%;}");
		document.write("td, th {border: 1px solid #dddddd; text-align: center;  padding: 8px;}");
		document.write("tr:nth-child(even) {background-color: #dddddd;}</style>");
		document.write("<h1 style=color:blue;text-align:center;>Sundry "+display+"</h1><table>");
		document.write("<tr><th>Id#</th><th>Sundry "+display+" Name</th><th>Phone Number</th><th>ACTION | " +'<button id="sundry_sync_all" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Sync All</button>'+ "</th></tr>");
		Swal.fire({
		     title: 'Loading Ledgers,Please Wait.'
		});
		Swal.showLoading();
		$.ajax({
		 	// url:  ipAddress+"v1/001/fetch_customer_data",
		 	type: "POST",
			 url: get_all_customer_url+$(this).data('invoice_type'),
			 // headers:{"Cookie":cookies},
			 dataType : "json",
			 contentType: "application/json; charset=utf-8",
			 data:json,
		 	// data:{'invoice_type':$(this).data('invoice_type')},
		 	 success: function(response) {
		 	 	// console.log(response);
		 	 	Swal.close();
				$.each(response.result, function (index, details) {
				ind++;
				document.write("<tr id='tr_"+ind+"'><td>" + (index+1) + "</td><td>" + details.ledger_name + "</td><td>" +
				details.phone_number +"</td><td>" +'<button id="add_'+ind+'" class="sundry_sync" data-send_another="true" style="background-color: blue;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Add Sundry '+display+' In Tally</button><button id="syncme_'+ind+'" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Mark As Sync</button>'+ "</td></tr>");

				$('#syncme_'+ind).on("click", function() {
                        var btn_id = $(this).attr('id');
                        object["params"] = {"status":true,'message':"Sundry "+display+" Marked As Sync SuccessFully!"};
                        json = JSON.stringify(object);
                        $.ajax({
                            type: 'post',
                            // url: 	ipAddress+'v1/001/payment_tally_sync_done',
                            // data: {payment_id: payment_service.payment_id, status: true, message: "Payment Marked As Sync SuccessFully!"},
                            url: tally_sync_url+"Customer/"+details.customer_id,
                        // headers:{"Cookie":cookies},
                            dataType : "json",
                            contentType: "application/json; charset=utf-8",
                            data:json,
                            success: function (responseMessage) {
                                      console.log(responseMessage);
                                      $('#'+btn_id).closest("tr").remove();
                            }
                         });
                        Swal.fire({
                            title: 'Sundry '+display+' Marked As Sync SuccessFully!',
                            type: 'success',
                            showConfirmButton:false,
                            timer:1500
                        });
                  });
			
			$('#add_'+ind).on("click", function () {
				  	var btn_id = $(this).attr('id');				  
				  		$.ajax({
				  				async: false,
								type: 'post',
								// url: ipAddress+'v1/001/fetch_customer',
								// data: {billing_shipping_id:details.billing_shipping_id},
								url: get_customer_url+details.customer_id,
								// headers:{"Cookie":cookies},
								dataType : "json",
								contentType: "application/json; charset=utf-8",
								data:json,
								success: function (response) {
										
									 	var company_name='', country='', email='', website='', panCard_number='', registration_type='',credit_period='', phone_number='', res_str= '', address='';
										var fax_number ='', contact_person_name='', mobile_number='', gst_number='', credit_limit='', ledger_name_alias='', pincode='', cc_email='';date='';
										var c_data = response.result//JSON.parse(response);
										$.each(c_data,function(index,data){
											// console.log(d.company_name);
											date=data.date;
											company_name = data.company_name; ledger_name = escapeHtml(data.ledger_name); address  = data.address; city = data.city;
											state = data.state; country = data.country; email = data.email; website = data.website;panCard_number = data.panCard_number;
											registration_type = data.registration_type; credit_period = data.credit_period; phone_number = data.phone_number; fax_number = data.fax_number;
											contact_person_name = escapeHtml(data.contact_person_name); mobile_number = data.mobile_number; gst_number = data.gst_number; credit_limit = data.credit_limit;
											ledger_name_alias = data.ledger_name_alias; pincode = data.pincode; cc_email= data.cc_email;
									
										});
									// alert(company_name);
									var final_address = '';
									var split_address = address.match(/.{1,35}/g);
									if (address != '\n\n\n' && address != '' && split_address != null) 
									{
										for (var i = 0; i < split_address.length; i++) 
										{
											final_address += '<ADDRESS>'+escapeHtml(split_address[i])+'</ADDRESS>';
										}
									}
									var final_address = '';

									if (address && address.trim() !== '' && address !== '\n\n\n') {
										var split_address = address.match(/.{1,35}/g);  // split in 35-char chunks
										if (split_address) {
											final_address += '<ADDRESS.LIST TYPE="String">';
											for (var i = 0; i < split_address.length; i++) {
												final_address += '<ADDRESS>' + escapeHtml(split_address[i]) + '</ADDRESS>';
											}
											final_address += '</ADDRESS.LIST>';
										}
									}

									// alert(final_address);
									
									res_str = '<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME><STATICVARIABLES><SVCURRENTCOMPANY>'+
									company_name+'</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC><REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF"><LEDGER NAME=\"'+ledger_name+'"\ RESERVEDNAME=""><TAXCLASSIFICATIONNAME>Not Applicable</TAXCLASSIFICATIONNAME><EMAIL>'+email+'</EMAIL><PINCODE>'+pincode+'</PINCODE><WEBSITE>'+website+'</WEBSITE><INCOMETAXNUMBER>'+panCard_number+'</INCOMETAXNUMBER><PARENT>Sundry '+display+'</PARENT><TAXCLASSIFICATIONNAME/><BILLCREDITPERIOD>'+
									credit_period+'</BILLCREDITPERIOD><COUNTRYOFRESIDENCE>'+country+'</COUNTRYOFRESIDENCE><EMAILCC>'+cc_email+'</EMAILCC><LEDGERMOBILE>'+phone_number+'</LEDGERMOBILE><LEDGERFAX>'+fax_number+'</LEDGERFAX><LEDGERCONTACT>'+
									contact_person_name+'</LEDGERCONTACT><LEDGERMOBILE>'+mobile_number+'</LEDGERMOBILE><GSTTYPE/><APPROPRIATEFOR/><PARTYGSTIN>'+gst_number+'</PARTYGSTIN><EXCISELEDGERCLASSIFICATION/><EXCISEDUTYTYPE/><EXCISENATUREOFPURCHASE/><LEDGERFBTCATEGORY/><PRIORSTATENAME>'+
									state+'</PRIORSTATENAME><ISBILLWISEON>Yes</ISBILLWISEON><ASORIGINAL>Yes</ASORIGINAL><ISCREDITDAYSCHKON>NO</ISCREDITDAYSCHKON><ISCHEQUEPRINTINGENABLED>Yes</ISCHEQUEPRINTINGENABLED><CREDITLIMIT>'+
									credit_limit+'</CREDITLIMIT><LANGUAGENAME.LIST> <NAME.LIST TYPE="String"><NAME>'+ledger_name+'</NAME><NAME>'+ledger_name_alias+'</NAME></NAME.LIST></LANGUAGENAME.LIST><LEDMAILINGDETAILS.LIST>' +
									'<APPLICABLEFROM>20250401</APPLICABLEFROM>' +final_address+    '<PINCODE>' + pincode +'</PINCODE>' +'<MAILINGNAME>' + ledger_name + '</MAILINGNAME>' +'<STATE>' + state + '</STATE>' +'<COUNTRY>' +country + '</COUNTRY>' +'</LEDMAILINGDETAILS.LIST> </LEDGER></TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"> <COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
									company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';	

								var http = new XMLHttpRequest();
							    var data = res_str;
							   		
							   	http.open('POST', ipAddressTally, false);
								http.onreadystatechange = function() {							   	
								    if(http.readyState == 4 && http.status == 200) {
								   	 var xmlDoc = http.responseXML;
								   	 if(xmlDoc.getElementsByTagName("LINEERROR")[0]!=null || xmlDoc.getElementsByTagName("ALTERED")[0].innerHTML=='0' && xmlDoc.getElementsByTagName("CREATED")[0].innerHTML=='0') {
		    						 var x = xmlDoc.getElementsByTagName("LINEERROR")[0]!=null?xmlDoc.getElementsByTagName("LINEERROR")[0].innerHTML:"UNKNOWN ERROR";
		    						 document.querySelectorAll('.sundry_sync')[0].setAttribute('data-send_another','');

							      	 $('.sundry_sync').each(function(){
							      	 	$(this).data('send_another','');
							      	 });
		    						/*  $.ajax({
										     type: 'post',
										     url: ipAddress+'v1/001/tally_sync_done',
										     data: {sale_id: sale_service.sale_id, status: false, message: x},
										     success: function (responseMessage) {
										               console.log(responseMessage);
										               // location.reload();
										     }
										  });	*/

		    						 Swal.fire({
							            title: x,
							            type: 'error',
							            showConfirmButton:false,
							            timer:1500
							      	 });
									} else {								
											object["params"] = {"status":true,'message':"Ledger SuccessFully Created !"};
											json = JSON.stringify(object);
											 $.ajax({
										     type: 'post',
										    //  url: 	ipAddress+'v1/001/customer_tally_sync_done',
										    //  data: {billing_shipping_id: details.billing_shipping_id, status: true, message: "Ledger SuccessFully Created !"},
											url: tally_sync_url+"Customer/"+details.customer_id,
										// headers:{"Cookie":cookies},
											dataType : "json",
											contentType: "application/json; charset=utf-8",
											data:json,
										     success: function (responseMessage) {
										               console.log(responseMessage);
										               $('#'+btn_id).closest("tr").remove();
										     }
										  });	
											 Swal.fire({
									            title: 'Sundry '+display+' SuccessFully Created!',
									            type: 'success',
									            showConfirmButton:false,
									            timer:1500
									      	});  
										}	 
								    } else {
								    	  if(http.readyState == 4 && http.status == 0) { 
								    	  	document.querySelectorAll('.sundry_sync')[0].setAttribute('data-send_another','');

									      	 $('.sundry_sync').each(function(){
									      	 	$(this).data('send_another','');
									      	 });
								    	  	Swal.fire({
									            title: 'Please Start Tally !!!',
									            type: 'error',
									            showConfirmButton:false,
									            timer:1500
									      	});
								    	  }
								    }
								}
					  			http.send(data);	

					    }});
				  });

				});

			 }});

		call_all_sync('#sundry_sync_all','.sundry_sync');
		
	});

	//Products fetch All
	$('#fetchProducts').on('click', function () {
	 var ind = 0;
		document.write("<script src='jquery-3.3.1.min.js'></script>");
		document.write("<script src='custom.js'></script>");
		document.write("<script src='sweetalert2.js'></script>");
		document.write("<style>table {font-family: arial, sans-serif;border-collapse: collapse;width: 100%;}");
		document.write("td, th {border: 1px solid #dddddd; text-align: center;  padding: 8px;}");
		document.write("tr:nth-child(even) {background-color: #dddddd;}</style>");
		document.write("<h1 style=color:blue;text-align:center;>Stock Item</h1><table>");
		document.write("<tr><th>Id#</th><th>Product Name</th><th>Product Price</th><th>ACTION | " +'<button id="product_sync_all" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Sync All</button>'+ "</th></tr>");
		Swal.fire({
		     title: 'Loading Products,Please Wait.'
		});
		Swal.showLoading();
//		object["params"] = {"status":true,'company_id':1};
//		json = JSON.stringify(object);
		$.ajax({
		 	// url:  ipAddress+"v1/001/fetch_product_data",
		 	type: "POST",
			 url: get_all_product_url,
			// headers:{"Cookie":cookies},
			dataType : "json",
			csrf:"False",
			contentType: "application/json; charset=utf-8",

			data:json,
		 	 success: function(response) {
		 	 	// console.log(response);
		 	 	Swal.close();
				$.each(response.result, function (index, details) {
				ind++;
				document.write("<tr id='tr_"+ind+"'><td>" + (index+1) + "</td><td>" + details.tally_product_name_mapper + "</td><td>" +
				details.product_ndp +"</td><td>" +'<button id="add_'+ind+'" class="product_sync" data-send_another="true" style="background-color: blue;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Add Stock Item In Tally</button>'+ "</td></tr>");			
				
				$('#add_'+ind).on("click", function (e) {
				  	var btn_id = $(this).attr('id');
				  
				  		$.ajax({
				  				async: false,
								type: 'post',
								// url: ipAddress+'v1/001/fetch_product',
								// data: {product_id:details.product_id,sale_id:details.sale_id,purchase_id:details.purchase_id},
								url: get_product_url+details.product_id,
								dataType : "json",
								contentType: "application/json; charset=utf-8",
								data:json,
								success: function (response) {
									 	var company_name='', product_id='', sale_id='', purchase_id='', tally_product_name_mapper='', product_ndp='', product_uom_id='',uom_name='', product_category_id='', product_category_name= '', parent_category_name='',parent_category_id='',default_product_category_name='',default_uom_name='',created_date='',created_date_next_month='',integrated_tax='',central_tax='',state_tax='',state='',res_str='';
										var p_data = response.result//JSON.parse(response);
										$.each(p_data,function(index,data){
											// console.log(d.company_name);
											company_name=data.company_name; product_id=data.product_id; sale_id=data.sale_id; purchase_id=data.purchase_id; tally_product_name_mapper=data.tally_product_name_mapper; product_ndp=data.product_ndp; product_uom_id=data.product_uom_id;uom_name=data.uom_name; product_category_id=data.product_category_id; product_category_name= data.product_category_name; parent_category_name=data.parent_category_name; parent_category_id=data.parent_category_id;default_product_category_name=data.default_product_category_name;default_uom_name=data.default_uom_name;created_date=data.created_date;created_date_next_month=data.created_date_next_month;integrated_tax=data.integrated_tax;central_tax=data.central_tax;state_tax=data.state_tax;state=data.state;
									
										});
									

									//ADD UOM
									if (uom_name != '' && product_uom_id != '') 
									{
										res_str = '<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>All Masters</REPORTNAME><STATICVARIABLES><SVCURRENTCOMPANY>'+
										company_name+'</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC><REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF"><UNIT NAME=\"'+uom_name+'"\ RESERVEDNAME=""><NAME>'+
										uom_name+'</NAME><ASORIGINAL>Yes</ASORIGINAL><ISSIMPLEUNIT>Yes</ISSIMPLEUNIT></UNIT></TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
										company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';	

										var http = new XMLHttpRequest();
									    var data = res_str;
									   		
									   	http.open('POST', ipAddressTally, false);
										http.onreadystatechange = function() {							   	
										    if(http.readyState == 4 && http.status == 200) {
										   	 var xmlDoc = http.responseXML;
										   	 if(xmlDoc.getElementsByTagName("LINEERROR")[0]!=null || xmlDoc.getElementsByTagName("ALTERED")[0].innerHTML=='0' && xmlDoc.getElementsByTagName("CREATED")[0].innerHTML=='0') {
				    						 var x = xmlDoc.getElementsByTagName("LINEERROR")[0]!=null?xmlDoc.getElementsByTagName("LINEERROR")[0].innerHTML:"UNKNOWN ERROR";
				    						 console.log(x);
				    						 document.querySelectorAll('.product_sync')[0].setAttribute('data-send_another','');

									      	 $('.product_sync').each(function(){
									      	 	$(this).data('send_another','');
									      	 });

											} else {								
												// 	object["params"] = {"status":true,'message':"Ledger SuccessFully Created !"};
												// 	 $.ajax({
												//      type: 'post',
												//     //  url: 	ipAddress+'v1/001/product_tally_sync_done',
												//     //  data: {product_uom_id: details.product_uom_id, status: true, message: "UOM SuccessFully Created!"},
												// 	url: tally_sync_url+"Customer/"+details.customer_id,
												// // headers:{"Cookie":cookies},
												// 	dataType : "json",
												// 	contentType: "application/json; charset=utf-8",
												// 	data:json,
												//      success: function (responseMessage) {
												//                console.log(responseMessage);
												//      }
												//   });	 
												}	 
										    } else {
										    	  if(http.readyState == 4 && http.status == 0) { 
										    	  	document.querySelectorAll('.product_sync')[0].setAttribute('data-send_another','');
											      	 $('.product_sync').each(function(){
											      	 	$(this).data('send_another','');
											      	 });
										    	  	Swal.fire({
											            title: 'Please Start Tally !!!',
											            type: 'error',
											            showConfirmButton:false,
											            timer:1500
											      	});
											      	
										    	  }
										    }
										}
							  			http.send(data);	
									}

									//STOCK GROUP ADD
									if (product_category_id != '' && product_category_name != '') 
									{
										if (parent_category_id != '' && parent_category_name != '') 
										{
								  			res_str = '<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>All Masters</REPORTNAME><STATICVARIABLES><SVCURRENTCOMPANY>'+
											company_name+'</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC><REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF"><STOCKGROUP NAME=\"'+parent_category_name+'"\ RESERVEDNAME=""><PARENT /><BASEUNITS /><ADDITIONALUNITS /><SERVICETAXDETAILS.LIST /><VATDETAILS.LIST /><SALESTAXCESSDETAILS.LIST /><GSTDETAILS.LIST /><LANGUAGENAME.LIST><NAME.LIST TYPE="String"><NAME>'+
											parent_category_name+'</NAME></NAME.LIST></LANGUAGENAME.LIST></STOCKGROUP></TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><STOCKGROUP NAME=\"'+product_category_name+'"\ RESERVEDNAME=""><PARENT>'+
											parent_category_name+'</PARENT><BASEUNITS /><ADDITIONALUNITS /><SERVICETAXDETAILS.LIST /><VATDETAILS.LIST /><SALESTAXCESSDETAILS.LIST /><GSTDETAILS.LIST /><LANGUAGENAME.LIST><NAME.LIST TYPE="String"><NAME>'+
											product_category_name+'</NAME></NAME.LIST></LANGUAGENAME.LIST></STOCKGROUP></TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
											company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';
											var http = new XMLHttpRequest();
										    var data = res_str;
										   	console.log(data);
										   	http.open('POST', ipAddressTally, false);
											http.onreadystatechange = function() {							   	
											    if(http.readyState == 4 && http.status == 200) {
											   	 var xmlDoc = http.responseXML;
											   	 console.log(xmlDoc);
											   	 if(xmlDoc.getElementsByTagName("LINEERROR")[0]!=null || xmlDoc.getElementsByTagName("ALTERED")[0].innerHTML=='0' && xmlDoc.getElementsByTagName("CREATED")[0].innerHTML=='0') {
					    						 var x = xmlDoc.getElementsByTagName("LINEERROR")[0]!=null?xmlDoc.getElementsByTagName("LINEERROR")[0].innerHTML:"UNKNOWN ERROR";
					    						 console.log(x);
					    						 document.querySelectorAll('.product_sync')[0].setAttribute('data-send_another','');
										      	 $('.product_sync').each(function(){
										      	 	$(this).data('send_another','');
										      	 });

												} else {								
													// 	 $.ajax({
													//      type: 'post',
													//      url: 	ipAddress+'v1/001/product_tally_sync_done',
													//      data: {parent_category_id: details.parent_category_id,product_category_id: details.product_category_id, status: true, message: "Product Category SuccessFully Created!"},
													//      success: function (responseMessage) {
													//                console.log(responseMessage);
													//      }
													//   });	 
													}	 
											    } else {
											    	  if(http.readyState == 4 && http.status == 0) { 
											    	  	document.querySelectorAll('.product_sync')[0].setAttribute('data-send_another','');

												      	 $('.product_sync').each(function(){
												      	 	$(this).data('send_another','');
												      	 });
											    	  	Swal.fire({
												            title: 'Please Start Tally !!!',
												            type: 'error',
												            showConfirmButton:false,
												            timer:1500
												      	});
												      	

											    	  }
											    }
											}
											
								  			http.send(data);
										}
										else
										{
											res_str = '<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>All Masters</REPORTNAME><STATICVARIABLES><SVCURRENTCOMPANY>'+
											company_name+'</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC><REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF"><STOCKGROUP NAME=\"'+product_category_name+'"\ RESERVEDNAME=""><PARENT /><BASEUNITS /><ADDITIONALUNITS /><SERVICETAXDETAILS.LIST /><VATDETAILS.LIST /><SALESTAXCESSDETAILS.LIST /><GSTDETAILS.LIST /><LANGUAGENAME.LIST><NAME.LIST TYPE="String"><NAME>'+
											product_category_name+'</NAME></NAME.LIST></LANGUAGENAME.LIST></STOCKGROUP></TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
											company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';	

											var http = new XMLHttpRequest();
										    var data = res_str;
										   	console.log(data);
										   	http.open('POST', ipAddressTally, false);
											http.onreadystatechange = function() {							   	
											    if(http.readyState == 4 && http.status == 200) {
											   	 var xmlDoc = http.responseXML;
											   	 console.log(xmlDoc);
											   	 if(xmlDoc.getElementsByTagName("LINEERROR")[0]!=null || xmlDoc.getElementsByTagName("ALTERED")[0].innerHTML=='0' && xmlDoc.getElementsByTagName("CREATED")[0].innerHTML=='0') {
					    						 var x = xmlDoc.getElementsByTagName("LINEERROR")[0]!=null?xmlDoc.getElementsByTagName("LINEERROR")[0].innerHTML:"UNKNOWN ERROR";
					    						 console.log(x);
					    						 document.querySelectorAll('.product_sync')[0].setAttribute('data-send_another','');

										      	 $('.product_sync').each(function(){
										      	 	$(this).data('send_another','');
										      	 });

												} else {								
													// 	 $.ajax({
													//      type: 'post',
													//      url: 	ipAddress+'v1/001/product_tally_sync_done',
													//      data: {product_category_id: details.product_category_id, status: true, message: "Product Category SuccessFully Created!"},
													//      success: function (responseMessage) {
													//                console.log(responseMessage);
													//      }
													//   });	
														 
													}	 
											    } else {
											    	document.querySelectorAll('.product_sync')[0].setAttribute('data-send_another','');
												      	 $('.product_sync').each(function(){
												      	 	$(this).data('send_another','');
												      	 });
											    	  if(http.readyState == 4 && http.status == 0) { 
											    	  	Swal.fire({
												            title: 'Please Start Tally !!!',
												            type: 'error',
												            showConfirmButton:false,
												            timer:1500
												      	});
												      	

											    	  }
											    }
											}
								  			http.send(data);
										}
											
									}
									//ADD PRODUCT
									res_str = '<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>All Masters</REPORTNAME><STATICVARIABLES><SVCURRENTCOMPANY>'+
										company_name+'</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC><REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF"><STOCKITEM NAME=\"'+escapeHtml(tally_product_name_mapper)+'"\ RESERVEDNAME=""><OLDAUDITENTRYIDS.LIST TYPE="Number"><OLDAUDITENTRYIDS>-1</OLDAUDITENTRYIDS></OLDAUDITENTRYIDS.LIST><PARENT>'+
										default_product_category_name+'</PARENT><CATEGORY /><GSTAPPLICABLE>Applicable</GSTAPPLICABLE><TAXCLASSIFICATIONNAME /><GSTTYPEOFSUPPLY>Goods</GSTTYPEOFSUPPLY><EXCISEAPPLICABILITY>Not Applicable</EXCISEAPPLICABILITY><SALESTAXCESSAPPLICABLE /><VATAPPLICABLE>Applicable</VATAPPLICABLE><COSTINGMETHOD>Avg. Cost</COSTINGMETHOD><VALUATIONMETHOD>Avg. Price</VALUATIONMETHOD><BASEUNITS>'+
										default_uom_name+'</BASEUNITS><ADDITIONALUNITS /><EXCISEITEMCLASSIFICATION /><VATBASEUNIT>'+
										default_uom_name+'</VATBASEUNIT><ASORIGINAL>Yes</ASORIGINAL><DENOMINATOR>1</DENOMINATOR><RATEOFVAT>0</RATEOFVAT><VATBASENO>1</VATBASENO><VATTRAILNO>1</VATTRAILNO><VATACTUALRATIO>1</VATACTUALRATIO><SERVICETAXDETAILS.LIST /><VATDETAILS.LIST /><SALESTAXCESSDETAILS.LIST /><GSTDETAILS.LIST><APPLICABLEFROM>'+
										created_date+'</APPLICABLEFROM><HSNMASTERNAME>'+
										integrated_tax+'%  GST</HSNMASTERNAME><STATEWISEDETAILS.LIST><STATENAME>Any</STATENAME><RATEDETAILS.LIST><GSTRATEDUTYHEAD>Central Tax</GSTRATEDUTYHEAD></RATEDETAILS.LIST><RATEDETAILS.LIST><GSTRATEDUTYHEAD>State Tax</GSTRATEDUTYHEAD></RATEDETAILS.LIST><RATEDETAILS.LIST><GSTRATEDUTYHEAD>Integrated Tax</GSTRATEDUTYHEAD></RATEDETAILS.LIST><RATEDETAILS.LIST><GSTRATEDUTYHEAD>Cess</GSTRATEDUTYHEAD></RATEDETAILS.LIST><RATEDETAILS.LIST><GSTRATEDUTYHEAD>Cess on Qty</GSTRATEDUTYHEAD><GSTRATEVALUATIONTYPE>Based on Quantity</GSTRATEVALUATIONTYPE></RATEDETAILS.LIST><GSTSLABRATES.LIST /></STATEWISEDETAILS.LIST><TEMPGSTDETAILSLABRATES.LIST /></GSTDETAILS.LIST><GSTDETAILS.LIST><APPLICABLEFROM>'+
										created_date_next_month+'</APPLICABLEFROM><CALCULATIONTYPE>On Value</CALCULATIONTYPE><HSNMASTERNAME /><TAXABILITY>Taxable</TAXABILITY><STATEWISEDETAILS.LIST><STATENAME>Any</STATENAME><RATEDETAILS.LIST><GSTRATEDUTYHEAD>Central Tax</GSTRATEDUTYHEAD><GSTRATEVALUATIONTYPE>Based on Value</GSTRATEVALUATIONTYPE><GSTRATE>'+
										central_tax+'</GSTRATE></RATEDETAILS.LIST><RATEDETAILS.LIST><GSTRATEDUTYHEAD>State Tax</GSTRATEDUTYHEAD><GSTRATEVALUATIONTYPE>Based on Value</GSTRATEVALUATIONTYPE><GSTRATE>'+
										state_tax+'</GSTRATE></RATEDETAILS.LIST><RATEDETAILS.LIST><GSTRATEDUTYHEAD>Integrated Tax</GSTRATEDUTYHEAD><GSTRATEVALUATIONTYPE>Based on Value</GSTRATEVALUATIONTYPE><GSTRATE>'+
										integrated_tax+'</GSTRATE></RATEDETAILS.LIST><RATEDETAILS.LIST><GSTRATEDUTYHEAD>Cess</GSTRATEDUTYHEAD><GSTRATEVALUATIONTYPE>Based on Value</GSTRATEVALUATIONTYPE></RATEDETAILS.LIST><RATEDETAILS.LIST><GSTRATEDUTYHEAD>Cess on Qty</GSTRATEDUTYHEAD><GSTRATEVALUATIONTYPE>Based on Quantity</GSTRATEVALUATIONTYPE></RATEDETAILS.LIST><GSTSLABRATES.LIST /></STATEWISEDETAILS.LIST><TEMPGSTDETAILSLABRATES.LIST /></GSTDETAILS.LIST><LANGUAGENAME.LIST><NAME.LIST TYPE="String"><NAME>'+
										escapeHtml(tally_product_name_mapper)+'</NAME></NAME.LIST></LANGUAGENAME.LIST></STOCKITEM></TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
										company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';
										var http = new XMLHttpRequest();
									    var data = res_str;
									   	console.log(data);
									   	http.open('POST', ipAddressTally, false);
										http.onreadystatechange = function() {		

										    if(http.readyState == 4 && http.status == 200) {
										   	 var xmlDoc = http.responseXML;
										   	 if(xmlDoc.getElementsByTagName("LINEERROR")[0]!=null || xmlDoc.getElementsByTagName("ALTERED")[0].innerHTML=='0' && xmlDoc.getElementsByTagName("CREATED")[0].innerHTML=='0') {
				    						 var x = xmlDoc.getElementsByTagName("LINEERROR")[0]!=null?xmlDoc.getElementsByTagName("LINEERROR")[0].innerHTML:"UNKNOWN ERROR";
				    						 document.querySelectorAll('.product_sync')[0].setAttribute('data-send_another','');

									      	 $('.product_sync').each(function(){
									      	 	$(this).data('send_another','');
									      	 });
				    						 Swal.fire({
									            title: x,
									            type: 'error',
									            showConfirmButton:false,
									            timer:1500
									      	 });

											} else {								
													object["params"] = {"status":true,'message':"Product SuccessFully Created!"};
													json = JSON.stringify(object);
													 $.ajax({
												     type: 'post',
												    //  url: 	ipAddress+'v1/001/product_tally_sync_done',
												    //  data: {product_id: details.product_id, parent_category_id: details.parent_category_id,product_category_id: details.product_category_id,product_uom_id: details.product_uom_id,status: true, message: "Product SuccessFully Created!"},
													url: tally_sync_url+"Product/"+details.product_id,
												// headers:{"Cookie":cookies},
													dataType : "json",
													contentType: "application/json; charset=utf-8",
													data:json,
												     success: function (responseMessage) {
												               console.log(responseMessage);
												               $('#'+btn_id).closest("tr").remove();
												     }
												  });	
													 Swal.fire({
											            title: 'Product SuccessFully Created!',
											            type: 'success',
											            showConfirmButton:false,
											            timer:1500
											      	});  
												}	 
										    } else {
										    	  if(http.readyState == 4 && http.status == 0) { 
										    	  	document.querySelectorAll('.product_sync')[0].setAttribute('data-send_another','');
											      	$('.product_sync').each(function(){
											      	 $(this).data('send_another','');
											      	});
										    	  	Swal.fire({
											            title: 'Please Start Tally !!!',
											            type: 'error',
											            showConfirmButton:false,
											            timer:1500
											      	});
									      	 		
											      	
										    	  }
										    }
										}
							  			http.send(data);	

					    }});
				  });

				});

			 }});

		call_all_sync('#product_sync_all','.product_sync');
		
	});

	//Purchase Invoice fetch All
	$('#fetchPurchaseInvoice').on("click", function () {
		var inx= 0;
		Swal.fire({
		     title: 'Loading Purchase Invoices,Please Wait.'
		});
		Swal.showLoading();
		$.ajax({
			// url: ipAddress+"v1/001/fetch_purchase_invoice_data",
			// type: "GET",
			url: get_all_purchase_url,
			// headers:{"Cookie":cookies},
			dataType : "json",
			contentType: "application/json; charset=utf-8",
			data:json,
			type: "POST",
			success: function(response) {
					Swal.close();
					document.write("<script src='jquery-3.3.1.min.js'></script>");
					document.write("<script src='custom.js'></script>");
					document.write("<script src='sweetalert2.js'></script>");	
					document.write("<style>table {font-family: arial, sans-serif;border-collapse: collapse;width: 100%;}");
					document.write("td, th {border: 1px solid #dddddd; text-align: center;  padding: 8px;}");
					document.write("tr:nth-child(even) {background-color: #dddddd;}</style>");
					
				     document.write("<h1 style=color:blue;text-align:center;>Purchase Invoice Table</h1><table>");
				     document.write("<tr><th>Id#</th><th>Invoice Number</th><th>Purchase Id</th><th>ACTION | " +'<button id="purchase_sync_all" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Sync All</button>'+ "</th></tr>");

					$.each(response.result, function (index, purchase_service) {
					inx++;
					document.write("<tr id='tr_"+inx+"''><td>" + (index+1) + "</td><td>" + purchase_service.invoice_no + " ("+ purchase_service.billing_name +" )(Amount: "+purchase_service.amount+")</td><td>" +
					purchase_service.purchase_id +"</td><td>" +'<button id="clickme_'+inx+'" class="purchase_sync" data-send_another="true" style="background-color: blue;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Add Purchase Invoice In Tally</button><button id="syncme_'+inx+'" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Mark As Sync</button>'+ "</td></tr>");

				  $('#syncme_'+inx).on("click", function() {
				 		var btn_id = $(this).attr('id');
						object["params"] = {"status":true,'message':"Purchase Marked As Sync SuccessFully!"};
						json = JSON.stringify(object);
				 		$.ajax({
						    type: 'post',
						    // url: 	ipAddress+'v1/001/payment_tally_sync_done',
						    // data: {payment_id: payment_service.payment_id, status: true, message: "Payment Marked As Sync SuccessFully!"},
							url: tally_sync_url+"Purchase/"+purchase_service.purchase_id,
						// headers:{"Cookie":cookies},
							dataType : "json",
							contentType: "application/json; charset=utf-8",
							data:json,
						    success: function (responseMessage) {
						              console.log(responseMessage);
						              $('#'+btn_id).closest("tr").remove();
						    }
						 });
						Swal.fire({
				            title: 'Purchase Marked As Sync SuccessFully!',
				            type: 'success',
				            showConfirmButton:false,
				            timer:1500
				      	});
				  });
				// purchase_service.sale_id +"</td><td>" +'<button id="clickme_'+inx+'" style="background-color: blue;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Add Sales In Tally</button>'+'<button id="addReceipt'+inx+'" style="background-color: blue;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Add Receipt In Tally</button>'+ "</td></tr>");			
				// document.getElementById("clickme_"+inx+"").disabled = Boolean(Number(purchase_service.tally_sync));

				  // $('#addReceipt'+inx).on("click", function () {
				  // 	var btn_id = $(this).attr('id');
				  // });

				  $('#clickme_'+inx).on("click", function() {
				 		var btn_id = $(this).attr('id');
				 		
				 		$.ajax({
				 				async: false,
								type: 'post',
								// url: ipAddress+'v1/001/fetch_purchase_invoice',
								// data: {purchase_id:purchase_service.purchase_id, invoice_no:purchase_service.invoice_no},

								url: get_purchase_url+purchase_service.purchase_id,
								// data: {sale_id:sale_service.sale_id, invoice_no:sale_service.invoice_no},
								dataType : "json",
								contentType: "application/json; charset=utf-8",
								data:json,
								success: function (response) {
								var res_item ='', res_purchase_service= '', bill_landing_no = '', delivery_note_date = '', bill_landing_date = '', orderDate = '';
							    var address = '', city = '', state = '', country= '', gst_number ='', destination='';
								var totalAmount ='', bill_of_landing_no ='', despatched_through ='' , despatch_doc_no='',other_reference ='';
							    var cgst = '',igst = '', refrenceNumber = '', narration = '', createDate = '', party_name = '', supplier_name = '', supplier_invoice_no = '',supplier_date = '';
							    var sgst = '', res_str = '', godown_name= '', company_name ='', item_description= '', discount = '', gst_name = '';
								var voucherNumber = '', contact = '', vehicle_no = '', delivery_note_no='', shipping_date='',order_number ='', voucher_type ='';
								var  roundoff_name ='', roundoff_description ='', roundoff_amount= '',  roundoff ='',igst_amount = 0,cgst_amount = 0,sgst_amount = 0,is_cancelled = '',action = '',tally_alter='';

								// var response ='[{"invoice_date":"2019-03-18","invoice_no":"125","sale_id":"120","party_name":"Aman","company_name":"Company-2","branch_name":"Main Location","contact":"40036768","address":"sattelite","state":"Gujarat","city":"Ahmedabad","country":"India","party_id":"1","vehicle_no":"GJ-01-AB1831","sale_total_amount":"7939","sale_amount_without_tax":"5426.07","total_quantity":"30.00","cgst":"868.31","sgst":"868.31","igst":"0.00","roundoff_amount":"0.18","reference_no":"asdqwe","delivery_note_no":"3212","delivery_note_date":"qweasd","despatch_doc_no":"1212","despatched_through":"van","destination":"surat","bill_landing_no":"4453","bill_landing_date":"01-05-2018","term_of_payment":"5 days","other_reference":"no_one","delivery_terms":"10 days","motor_vehicle_no":"GJ01ER1223","narration":"","order_number":"PO-45","orderDate":"12-03-2019","challan_id":"34","challan_number":"45","sale_item":[{"product_id":"14","item_name":"Apollo TL 165/60R14 Amazer 4G Life","item_description":"desc2","psi_id":"142","psi_deleted":"0","quantity_sales":"10.00","uom_id":"1","uom_name":"kgs","price_per_unit_without_tax":"100.00","price":"1000.00","price_without_tax":"1000.00","price_with_tax":"781.25","item_cgst":"109.38","item_sgst":"109.38","item_igst":"0.00","tax_roundoff":"-0.01","discount":"0.00","item_total_amount":"1000.00","item_available_quantity":"4880.00","gst_id":"3","integrated_tax":"GST Sales 28%"},{"product_id":"15","item_name":"65mm Link Lock","item_description":"desc2","psi_id":"143","psi_deleted":"0","quantity_sales":"20.00","uom_id":"3","uom_name":"ltrs","price_per_unit_without_tax":"260.11","price":"5202.20","price_without_tax":"5202.20","price_with_tax":"4644.82","item_cgst":"278.69","item_sgst":"278.69","item_igst":"0.00","tax_roundoff":"0.00","discount":"0.00","item_total_amount":"5202.20","item_available_quantity":"43897.00","gst_id":"4","integrated_tax":"GST Sales 28%"}]}]';  
								// var response1 ='[{"invoice_date":"2019-03-29","invoice_no":"126","sale_id":"121","party_name":"AMAN","company_name":"Company-2","branch_name":"Main Location","contact":"40036768","address":"sattelite","state":"Gujarat","city":"Ahmedabad","country":"India","party_id":"1","vehicle_no":"GJ-01-AB1831","sale_total_amount":"6202.00","sale_amount_without_tax":"4845.47","total_quantity":"30.00","cgst":"678.37","sgst":"678.37","igst":"0.00","roundoff_amount":"-0.21","reference_no":"asdqwe","delivery_note_no":"3212","delivery_note_date":"qweasd","despatch_doc_no":"1212","despatched_through":"van","destination":"surat","bill_landing_no":"4453","bill_landing_date":"01-05-2018","term_of_payment":"5 days","other_reference":"no_one","delivery_terms":"10 days","motor_vehicle_no":"GJ01ER1223","narration":"","order_number":"PO-48","orderDate":"12-03-2019","challan_id":"37","challan_number":"48","sale_item":[{"product_id":"14","item_name":"Apollo TL 165\/60R14 Amazer 4G Life","item_description":"desc2","psi_id":"144","psi_deleted":"0","quantity_sales":"10.00","uom_id":"1","uom_name":"kgs","price_per_unit_without_tax":"100.00","price":"1000.00","price_without_tax":"1000.00","price_with_tax":"781.25","item_cgst":"109.38","item_sgst":"109.38","item_igst":"0.00","tax_roundoff":"-0.01","discount":"0.00","item_total_amount":"1000.00","item_available_quantity":"4869.00","gst_id":"3","integrated_tax":"GST Sales 28%"},{"product_id":"15","item_name":"65mm Link Lock","item_description":"desc2","psi_id":"145","psi_deleted":"0","quantity_sales":"20.00","uom_id":"3","uom_name":"ltrs","price_per_unit_without_tax":"260.11","price":"5202.20","price_without_tax":"5202.20","price_with_tax":"4064.22","item_cgst":"568.99","item_sgst":"568.99","item_igst":"0.00","tax_roundoff":"0.00","discount":"0.00","item_total_amount":"5202.20","item_available_quantity":"43877.00","gst_id":"3","integrated_tax":"GST Sales 28%"}]}]';  
								
								console.log(response);
								if (response.error != undefined) 
								{
									document.querySelectorAll('.purchase_sync')[0].setAttribute('data-send_another','');
								      $('.purchase_sync').each(function(){
								       	$(this).data('send_another','');
								      });
		    						 Swal.fire({
							            title: response.error,
							            type: 'error',
							            showConfirmButton:false,
							            timer:1500
								     });
								}	
								if (purchase_service.billing_name == '<span style="color:red">PURGED</span>') 
								{
									is_cancelled = '<ISCANCELLED>Yes</ISCANCELLED>';
									action = 'Cancel';
								}
								else
								{
									action = 'Create';
								}
								
								$.each(response.result ,function(i, purchaseDetails) {
								   
								   party_name = escapeHtml(purchaseDetails.party_name);
								   supplier_name = escapeHtml(purchaseDetails.supplier_name);
								   if (purchaseDetails.igst > 0) 
								   {
								   	 igst_amount = purchaseDetails.igst;
								   }
								   if (purchaseDetails.cgst > 0 && purchaseDetails.sgst > 0) 
								   {
								   	 cgst_amount = purchaseDetails.cgst;
								     sgst_amount = purchaseDetails.sgst;
								   }
								   total_amount = purchaseDetails.purchase_total_amount;
								   narration = purchaseDetails.narration;
								   voucherNumber = purchaseDetails.invoice_no;
								   refrenceNumber = purchaseDetails.invoice_no;
								   godown_name = purchaseDetails.branch_name;
								   company_name = purchaseDetails.company_name;
								   contact = purchaseDetails.contact;
								   address = purchaseDetails.address;
								   city = purchaseDetails.city;
								   state = purchaseDetails.state;
								   country = purchaseDetails.country;
								   despatch_doc_no = purchaseDetails.despatch_doc_no;
								   despatched_through = purchaseDetails.despatched_through;
								   destination = purchaseDetails.destination;
								   vehicle_no = purchaseDetails.vehicle_no;
								   bill_landing_no = purchaseDetails.bill_landing_no;
								   other_reference = purchaseDetails.other_reference;
								   delivery_note_date = purchaseDetails.delivery_note_date;
								   bill_landing_date = purchaseDetails.bill_landing_date;
								   delivery_note_no = purchaseDetails.delivery_note_no;
								   order_number = purchaseDetails.order_number;
								   orderDate = purchaseDetails.orderDate;
								   roundoff_amount = purchaseDetails.roundoff_amount;
								   supplier_date = purchaseDetails.supplier_date;
								   supplier_invoice_no = purchaseDetails.supplier_invoice_no;
								   // roundoff_amount = -0.03;
								   roundoff_name = 'ROUND OFF';
								   roundoff_description = '';
								   voucher_type = purchaseDetails.voucher_type;
								   // gst_sale = purchaseDetails.gst_sale;
								   createDate = purchaseDetails.invoice_date;
								   let s = new Date(purchaseDetails.invoice_date);
								   let tallyDate = s.getFullYear().toString() +
												s.getDate().toString().padStart(2, '0') +
												(s.getMonth() + 1).toString().padStart(2, '0');
								   tally_alter = purchaseDetails.tally_alter;
								   // console.log("invoice Date : "+createDate);
								   // createDate = formatDate(originalDate);  
								  	 // createDate = '02-05-2019';
								
									//Party Ledger and Total Purchase Amount Tag
								    totalAmount += '<LEDGERENTRIES.LIST><LEDGERNAME>'+
								 			   party_name+'</LEDGERNAME> <GSTCLASS/><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><ISLASTDEEMEDPOSITIVE>No</ISLASTDEEMEDPOSITIVE><AMOUNT>'+
								 			   total_amount+'</AMOUNT><BILLALLOCATIONS.LIST><NAME>'+
								 			   supplier_invoice_no+'</NAME><BILLTYPE>New Ref</BILLTYPE><AMOUNT>'+
								  			   total_amount+'</AMOUNT></BILLALLOCATIONS.LIST></LEDGERENTRIES.LIST>';
								  	if (igst_amount>0) 
								  	{
								  		igst += '<LEDGERENTRIES.LIST><ROUNDTYPE/><LEDGERNAME>IGST</LEDGERNAME><VOUCHERFBTCATEGORY/><GSTCLASS/><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><AMOUNT>-'+
								   			igst_amount+'</AMOUNT><VATEXPAMOUNT>-'+
								   			igst_amount+'</VATEXPAMOUNT><GSTDUTYAMOUNT>-'+
										    igst_amount+'</GSTDUTYAMOUNT></LEDGERENTRIES.LIST>';
								  	}		   
								   else if(cgst_amount > 0 && sgst_amount > 0)
								   {
								   		cgst += '<LEDGERENTRIES.LIST><ROUNDTYPE/><LEDGERNAME>CGST</LEDGERNAME><VOUCHERFBTCATEGORY/><GSTCLASS/><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><AMOUNT>-'+
								   			cgst_amount+'</AMOUNT><VATEXPAMOUNT>-'+
								   			cgst_amount+'</VATEXPAMOUNT><GSTDUTYAMOUNT>-'+
										    cgst_amount+'</GSTDUTYAMOUNT></LEDGERENTRIES.LIST>';
								  
								   		sgst += '<LEDGERENTRIES.LIST><ROUNDTYPE/><LEDGERNAME>SGST</LEDGERNAME><VOUCHERFBTCATEGORY/><GSTCLASS/><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><AMOUNT>-'+
								 		   sgst_amount+'</AMOUNT><VATEXPAMOUNT>-'+
								   		   sgst_amount+'</VATEXPAMOUNT><GSTDUTYAMOUNT>-'+
								   		   sgst_amount+'</GSTDUTYAMOUNT></LEDGERENTRIES.LIST>';
								   }

								   
								   if(purchaseDetails.roundoff_amount < 0.00) {
									  
								   roundoff += '<LEDGERENTRIES.LIST><LEDGERNAME>'+
								   			roundoff_name+'</LEDGERNAME><GSTCLASS/><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><REMOVEZEROENTRIES>No</REMOVEZEROENTRIES><ISPARTYLEDGER>No</ISPARTYLEDGER><ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE><ISCAPVATTAXALTERED>No</ISCAPVATTAXALTERED><ISCAPVATNOTCLAIMED>No</ISCAPVATNOTCLAIMED><AMOUNT>'+
								            Math.abs(roundoff_amount)+'</AMOUNT><VATEXPAMOUNT>'+
								            Math.abs(roundoff_amount)+'</VATEXPAMOUNT><UDF:USERDESCRIPTION.LIST DESC="`User Description`" ISLIST="YES" TYPE="String" INDEX="29"><UDF:USERDESCRIPTION DESC="`User Description`">'+
								            roundoff_description+'</UDF:USERDESCRIPTION></UDF:USERDESCRIPTION.LIST></LEDGERENTRIES.LIST>';
											
								    }
									else if(purchaseDetails.roundoff_amount > 0.00){
										
										roundoff += '<LEDGERENTRIES.LIST><LEDGERNAME>'+
								   			roundoff_name+'</LEDGERNAME><GSTCLASS/><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><REMOVEZEROENTRIES>No</REMOVEZEROENTRIES><ISPARTYLEDGER>No</ISPARTYLEDGER><ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE><ISCAPVATTAXALTERED>No</ISCAPVATTAXALTERED><ISCAPVATNOTCLAIMED>No</ISCAPVATNOTCLAIMED><AMOUNT>-'+
								            roundoff_amount+'</AMOUNT><VATEXPAMOUNT>-'+
								            roundoff_amount+'</VATEXPAMOUNT><UDF:USERDESCRIPTION.LIST DESC="`User Description`" ISLIST="YES" TYPE="String" INDEX="29"><UDF:USERDESCRIPTION DESC="`User Description`">'+
								            roundoff_description+'</UDF:USERDESCRIPTION></UDF:USERDESCRIPTION.LIST></LEDGERENTRIES.LIST>';
									}   	
						 		
						 			//purchase Item Detail	   
									if (purchaseDetails.purchase_item != '') 
									{	
									      $.each(purchaseDetails.purchase_item, function(index, purchase_item) {					
										  itemName = escapeHtml(purchase_item.item_name);
										  
									      rate = purchase_item.price_per_unit_without_tax;
									      quantity = purchase_item.quantity_purchased;
									      amount = purchase_item.price_without_tax;
									      item_description = escapeHtml(purchase_item.item_description);
									      discount = purchase_item.discount;
									      gst_name = purchase_item.integrated_tax;

										  res_item += "<ALLINVENTORYENTRIES.LIST><BASICUSERDESCRIPTION.LIST TYPE='String'><BASICUSERDESCRIPTION>"+
										  			  item_description+"</BASICUSERDESCRIPTION></BASICUSERDESCRIPTION.LIST><STOCKITEMNAME>"+
													  itemName+"</STOCKITEMNAME><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE><RATE>"+
													  rate+"</RATE><DISCOUNT>"+
													  discount+"</DISCOUNT><AMOUNT>-"+
													  amount+"</AMOUNT><ACTUALQTY>"+
													  quantity+"</ACTUALQTY><BILLEDQTY>"+
													  quantity+"</BILLEDQTY><BATCHALLOCATIONS.LIST><GODOWNNAME>"+
													  godown_name+"</GODOWNNAME><DESTINATIONGODOWNNAME>"+
													  godown_name+"</DESTINATIONGODOWNNAME><AMOUNT>-"+
													  amount+"</AMOUNT><ACTUALQTY>"+
													  quantity+"</ACTUALQTY><BILLEDQTY>"+
													  quantity+"</BILLEDQTY></BATCHALLOCATIONS.LIST><ACCOUNTINGALLOCATIONS.LIST><LEDGERNAME>Purchase</LEDGERNAME><AMOUNT>-"+
													  amount+"</AMOUNT></ACCOUNTINGALLOCATIONS.LIST></ALLINVENTORYENTRIES.LIST>";
										});
									}
								//purchase service
								 if(purchaseDetails.purchase_service != '') {
								 	var item_name = '', item_total_amount= '', item_description= '', price_without_tax = '';
								 	$.each(purchaseDetails.purchase_service, function (index, purchase_service) {
								 		 item_name = purchase_service.service_name;
								 		 item_total_amount = purchase_service.price_without_tax;
								 		 
								 		res_purchase_service += '<LEDGERENTRIES.LIST><OLDAUDITENTRYIDS.LIST TYPE="Number"><OLDAUDITENTRYIDS>-1</OLDAUDITENTRYIDS></OLDAUDITENTRYIDS.LIST><LEDGERNAME>'+
								 						escapeHtml(item_name)+'</LEDGERNAME><GSTCLASS/><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><AMOUNT>-'+
								 						item_total_amount+'</AMOUNT><VATEXPAMOUNT>-'+
								 						item_total_amount+'</VATEXPAMOUNT></LEDGERENTRIES.LIST>';
								 	});		
								 }
								var vehicle_no_display = '';
								if (vehicle_no != null) 
								{
									vehicle_no_display = vehicle_no;
								}
								var final_address = '';
								var split_address = address.match(/.{1,20}/g);
								if (address != '\n\n\n' && address != '') 
								{
									for (var i = 0; i < split_address.length; i++) 
									{
										final_address += '<ADDRESS>'+escapeHtml(split_address[i])+'</ADDRESS>';
									}
								}
								var contact_no = '';
								if (contact != 0) 
								{
									contact_no = contact;
								}
								// alert(tally_alter);
								if (tally_alter == 0) 
								{
									//CREATE
									res_str = '<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME><STATICVARIABLES><SVCURRENTCOMPANY>'+
										  company_name+'</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC><REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF"><VOUCHER  ACTION="'+action+'" OBJVIEW="Invoice Voucher View"><ADDRESS.LIST TYPE="String">'+
										  final_address+'<ADDRESS>'+
										  city+'</ADDRESS><ADDRESS>'+
										  vehicle_no_display+'</ADDRESS><ADDRESS>'+
										  contact_no+'</ADDRESS></ADDRESS.LIST><OLDAUDITENTRYIDS.LIST TYPE="Number"><OLDAUDITENTRYIDS>-1</OLDAUDITENTRYIDS></OLDAUDITENTRYIDS.LIST><DATE>'+
										  tallyDate+'</DATE><REFERENCEDATE>'+
										  supplier_date+'</REFERENCEDATE><STATENAME>'+
										  state+'</STATENAME><NARRATION>'+
										  escapeHtml(narration)+'</NARRATION><COUNTRYOFRESIDENCE>'+
										  country+'</COUNTRYOFRESIDENCE><PARTYGSTIN>'+
										  gst_number+'</PARTYGSTIN><CLASSNAME>DefaultVoucherClass</CLASSNAME><PARTYNAME>'+
										  supplier_name+'</PARTYNAME><VOUCHERTYPENAME>'+
										  voucher_type+'</VOUCHERTYPENAME><REFERENCE>'+
										  supplier_invoice_no+'</REFERENCE><VOUCHERNUMBER>'+
										  voucherNumber+'</VOUCHERNUMBER><PARTYLEDGERNAME>'+
										  party_name+'</PARTYLEDGERNAME><BASICBASEPARTYNAME>'+
										  party_name+'</BASICBASEPARTYNAME><CSTFORMISSUETYPE/><CSTFORMRECVTYPE/><FBTPAYMENTTYPE>Default</FBTPAYMENTTYPE><PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW><BILLOFLADINGNO>'+
										  bill_of_landing_no+'</BILLOFLADINGNO><PLACEOFSUPPLY>'+
										  state+'</PLACEOFSUPPLY><BASICSHIPPEDBY>'+
										  despatched_through+'</BASICSHIPPEDBY><BASICBUYERNAME>'+
										  supplier_name+'</BASICBUYERNAME><BASICSHIPDOCUMENTNO>'+
										  despatch_doc_no+'</BASICSHIPDOCUMENTNO><BASICFINALDESTINATION>'+
										  destination+'</BASICFINALDESTINATION><BASICORDERREF>'+
										  other_reference+'</BASICORDERREF><BASICDATETIMEOFINVOICE>'+
										  tallyDate+'</BASICDATETIMEOFINVOICE><BASICDATETIMEOFREMOVAL>'+
										  tallyDate+'</BASICDATETIMEOFREMOVAL><VCHGSTCLASS/><CONSIGNEESTATENAME>'+
										  state+'</CONSIGNEESTATENAME><EFFECTIVEDATE>'+
										  tallyDate+'</EFFECTIVEDATE>'+
										  is_cancelled+'<ISINVOICE>Yes</ISINVOICE><HASDISCOUNTS>Yes</HASDISCOUNTS><ISVATDUTYPAID>Yes</ISVATDUTYPAID><INVOICEDELNOTES.LIST><BASICSHIPPINGDATE>'+
										  delivery_note_date+'</BASICSHIPPINGDATE><BASICSHIPDELIVERYNOTE>'+
										  delivery_note_no+'</BASICSHIPDELIVERYNOTE></INVOICEDELNOTES.LIST><INVOICEORDERLIST.LIST><BASICORDERDATE>'+
										  orderDate+'</BASICORDERDATE><BASICPURCHASEORDERNO>'+
										  order_number+'</BASICPURCHASEORDERNO></INVOICEORDERLIST.LIST> '+
										  totalAmount+' '+res_purchase_service+' '+igst+' '+cgst+' '+sgst+' '+roundoff+' '+res_item+' </VOUCHER> </TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
										  company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+
										  state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
										  company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+
										  state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';
								}
								else
								{
									//ALTER
									res_str = '<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME><STATICVARIABLES><SVCURRENTCOMPANY>'+
										  company_name+'</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC><REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF"><VOUCHER DATE="'+tallyDate+'" TAGNAME="Voucher Number" TAGVALUE="'+voucherNumber+'" ACTION="Alter" VCHTYPE="'+voucher_type+'"><ADDRESS.LIST TYPE="String">'+
										  final_address+'<ADDRESS>'+
										  city+'</ADDRESS><ADDRESS>'+
										  vehicle_no_display+'</ADDRESS><ADDRESS>'+
										  contact_no+'</ADDRESS></ADDRESS.LIST><OLDAUDITENTRYIDS.LIST TYPE="Number"><OLDAUDITENTRYIDS>-1</OLDAUDITENTRYIDS></OLDAUDITENTRYIDS.LIST><DATE>'+
										  tallyDate+'</DATE><REFERENCEDATE>'+
										  supplier_date+'</REFERENCEDATE><STATENAME>'+
										  state+'</STATENAME><NARRATION>'+
										  escapeHtml(narration)+'</NARRATION><COUNTRYOFRESIDENCE>'+
										  country+'</COUNTRYOFRESIDENCE><PARTYGSTIN>'+
										  gst_number+'</PARTYGSTIN><CLASSNAME>DefaultVoucherClass</CLASSNAME><PARTYNAME>'+
										  supplier_name+'</PARTYNAME><VOUCHERTYPENAME>'+
										  voucher_type+'</VOUCHERTYPENAME><REFERENCE>'+
										  supplier_invoice_no+'</REFERENCE><VOUCHERNUMBER>'+
										  voucherNumber+'</VOUCHERNUMBER><PARTYLEDGERNAME>'+
										  party_name+'</PARTYLEDGERNAME><BASICBASEPARTYNAME>'+
										  party_name+'</BASICBASEPARTYNAME><CSTFORMISSUETYPE/><CSTFORMRECVTYPE/><FBTPAYMENTTYPE>Default</FBTPAYMENTTYPE><PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW><BILLOFLADINGNO>'+
										  bill_of_landing_no+'</BILLOFLADINGNO><PLACEOFSUPPLY>'+
										  state+'</PLACEOFSUPPLY><BASICSHIPPEDBY>'+
										  despatched_through+'</BASICSHIPPEDBY><BASICBUYERNAME>'+
										  supplier_name+'</BASICBUYERNAME><BASICSHIPDOCUMENTNO>'+
										  despatch_doc_no+'</BASICSHIPDOCUMENTNO><BASICFINALDESTINATION>'+
										  destination+'</BASICFINALDESTINATION><BASICORDERREF>'+
										  other_reference+'</BASICORDERREF><BASICDATETIMEOFINVOICE>'+
										  tallyDate+'</BASICDATETIMEOFINVOICE><BASICDATETIMEOFREMOVAL>'+
										  tallyDate+'</BASICDATETIMEOFREMOVAL><VCHGSTCLASS/><CONSIGNEESTATENAME>'+
										  state+'</CONSIGNEESTATENAME><EFFECTIVEDATE>'+
										  tallyDate+'</EFFECTIVEDATE>'+
										  is_cancelled+'<ISINVOICE>Yes</ISINVOICE><HASDISCOUNTS>Yes</HASDISCOUNTS><ISVATDUTYPAID>Yes</ISVATDUTYPAID><INVOICEDELNOTES.LIST><BASICSHIPPINGDATE>'+
										  delivery_note_date+'</BASICSHIPPINGDATE><BASICSHIPDELIVERYNOTE>'+
										  delivery_note_no+'</BASICSHIPDELIVERYNOTE></INVOICEDELNOTES.LIST><INVOICEORDERLIST.LIST><BASICORDERDATE>'+
										  orderDate+'</BASICORDERDATE><BASICPURCHASEORDERNO>'+
										  order_number+'</BASICPURCHASEORDERNO></INVOICEORDERLIST.LIST> '+
										  totalAmount+' '+res_purchase_service+' '+igst+' '+cgst+' '+sgst+' '+roundoff+' '+res_item+' </VOUCHER> </TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
										  company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+
										  state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
										  company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+
										  state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';
								}
										
							  	 var http = new XMLHttpRequest();
							    var data = res_str;
							    console.log(data);		    		
							   	http.open('POST', ipAddressTally, false);
								http.onreadystatechange = function() {							   	
								    if(http.readyState == 4 && http.status == 200) {
								   	 var xmlDoc = http.responseXML;
								   	 if(xmlDoc.getElementsByTagName("LINEERROR")[0]!=null || xmlDoc.getElementsByTagName("ALTERED")[0].innerHTML=='0' && xmlDoc.getElementsByTagName("CREATED")[0].innerHTML=='0') {
		    						 var x = xmlDoc.getElementsByTagName("LINEERROR")[0]!=null?xmlDoc.getElementsByTagName("LINEERROR")[0].innerHTML:"UNKNOWN ERROR";
		    						 document.querySelectorAll('.purchase_sync')[0].setAttribute('data-send_another','');
								      $('.purchase_sync').each(function(){
								       	$(this).data('send_another','');
								      });
		    						 // Swal.fire(x);
		    						//   $.ajax({
										  //    type: 'post',
										  //    url: ipAddress+'v1/001/purchase_tally_sync_done',
										  //    data: {purchase_id: purchase_service.purchase_id, status: false, message: x},
										  //    success: function (responseMessage) {
										  //              console.log(responseMessage);
										  //              // location.reload();
										  //    }
										  // });	

		    						 Swal.fire({
							            title: x,
							            type: 'error',
							            showConfirmButton:false,
							            timer:1500
								     });
									} else {								
											object["params"] = {"status":true,'message':"Purchase Invoice SuccessFully Created !"};
											json = JSON.stringify(object);
											 $.ajax({
										     type: 'post',
										    //  url: 	ipAddress+'v1/001/purchase_tally_sync_done',
										    //  data: {purchase_id: purchase_service.purchase_id, status: true, message: "Purchase Invoice SuccessFully Created !"},
											url: tally_sync_url+"Purchase/"+purchase_service.purchase_id,
										// headers:{"Cookie":cookies},
											dataType : "json",
											contentType: "application/json; charset=utf-8",
											data:json,
										     success: function (responseMessage) {
										               console.log(responseMessage);
										               $('#'+btn_id).closest("tr").remove();
										     }
										  });	
											Swal.fire({
									            title: 'Purchase Invoice SuccessFully Created!',
									            type: 'success',
									            showConfirmButton:false,
									            timer:1500
									      	});	  
										}	 
								    } else {
								    	  if(http.readyState == 4 && http.status == 0) { 
								    	  	document.querySelectorAll('.purchase_sync')[0].setAttribute('data-send_another','');
									      	$('.purchase_sync').each(function(){
									       		$(this).data('send_another','');
									      	});
								    	  	Swal.fire({
									            title: 'Please Start Tally !!!',
									            type: 'error',
									            showConfirmButton:false,
									            timer:1500
									      	});
								    	  }
								    }
								}
					  			http.send(data);

							  	});   

							  }, 
							  error: function(error) {
							  document.querySelectorAll('.purchase_sync')[0].setAttribute('data-send_another','');
						      $('.purchase_sync').each(function(){
						       	$(this).data('send_another','');
						      });
							  Swal.fire({
					            title: 'Purchase Id Not Found!!!',
					            type: 'error',
					            showConfirmButton:false,
					            timer:1500
					      	  });
							}	
						});	
					});

			  	 });
					document.write("</table>");	
				call_all_sync('#purchase_sync_all','.purchase_sync');
			}, 
			    error: function(error) {
			    	document.querySelectorAll('.purchase_sync')[0].setAttribute('data-send_another','');
				      $('.purchase_sync').each(function(){
				       	$(this).data('send_another','');
				      });
			    	Swal.fire({
			            title: 'Api Not Found!!!',
			            type: 'error',
			            showConfirmButton:false,
			            timer:1500
			      	});
				}
		});
	


	});

	//Payment fetch All
	$('#fetchPayment').on("click", function () {
		var inx= 0;
		Swal.fire({
		     title: 'Loading Payments,Please Wait.'
		});
		Swal.showLoading();
		$.ajax({
			// url: ipAddress+"v1/001/fetch_payment_data",
			// type: "GET",
			url: get_all_payment_url,
			// headers:{"Cookie":cookies},
			dataType : "json",
			contentType: "application/json; charset=utf-8",
			data:json,
			type: "POST",
			success: function(response) {
					Swal.close();
					document.write("<script src='jquery-3.3.1.min.js'></script>");
					document.write("<script src='custom.js'></script>");
					document.write("<script src='sweetalert2.js'></script>");	
					document.write("<style>table {font-family: arial, sans-serif;border-collapse: collapse;width: 100%;}");
					document.write("td, th {border: 1px solid #dddddd; text-align: center;  padding: 8px;}");
					document.write("tr:nth-child(even) {background-color: #dddddd;}</style>");
					
				     document.write("<h1 style=color:blue;text-align:center;>Payment Table</h1><table>");
				     document.write("<tr><th>Id#</th><th>Payment Number</th><th>Payments Id</th><th>ACTION | " +'<button id="payment_sync_all" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Sync All</button>'+ "</th></tr>");

					$.each(response.result, function (index, payment_service) {
					inx++;
					document.write("<tr id='tr_"+inx+"''><td>" + (index+1) + "</td><td>" + payment_service.payment_no + " ("+ payment_service.billing_name +" )(Amount: "+payment_service.amount+")</td><td>" +
					payment_service.payment_id +"</td><td>" +'<button id="clickme_'+inx+'" class="payment_sync" data-send_another="true"  style="background-color: blue;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Add Payment In Tally</button><button id="syncme_'+inx+'" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Mark As Sync</button>'+ "</td></tr>");			
				  $('#syncme_'+inx).on("click", function() {
				 		var btn_id = $(this).attr('id');
						object["params"] = {"status":true,'message':"Payment Marked As Sync SuccessFully!"};
						json = JSON.stringify(object);
				 		$.ajax({
						    type: 'post',
						    // url: 	ipAddress+'v1/001/payment_tally_sync_done',
						    // data: {payment_id: payment_service.payment_id, status: true, message: "Payment Marked As Sync SuccessFully!"},
							url: tally_sync_url+"Payment/"+payment_service.payment_id,
						// headers:{"Cookie":cookies},
							dataType : "json",
							contentType: "application/json; charset=utf-8",
							data:json,
						    success: function (responseMessage) {
						              console.log(responseMessage);
						              $('#'+btn_id).closest("tr").remove();
						    }
						 });	
						Swal.fire({
				            title: 'Payment Marked As Sync SuccessFully!',
				            type: 'success',
				            showConfirmButton:false,
				            timer:1500
				      	});	
				  });
				  $('#clickme_'+inx).on("click", function() {
				 		var btn_id = $(this).attr('id');
				 		
				 		$.ajax({
				 				async: false,
								type: 'post',
								// url: ipAddress+'v1/001/fetch_payment',
								// data: {payment_id:payment_service.payment_id},
								url: get_payment_url+payment_service.payment_id,
								dataType : "json",
								contentType: "application/json; charset=utf-8",
								data:json,
								success: function (response) {
								var tally_ledger_name_mapper = '',res_bill_details ='', res_payment_details= '', address = '', city = '', state = '', country= '', gst_number ='', total_amount ='', narration = '', res_str = '', godown_name= '', company_name ='', voucherNumber = '', voucher_name ='',payment_date = '',payment_date_another_format = '',bill_details = '',payment_details = '',tally_alter='';

								// var response ='[{"payment_id":"1","payment_date":"20190923","payment_no":"1","voucher_id":"29","voucher_name":"Payment","tally_ledger_name_mapper":"MANISH RATHOD \/ GJ01RA8002 \/ 8320497669","total_amount":"3000","party_name":"MANISH RATHOD","c_name":"Manish Rathod","gst":"","address":"Ahmedabad\\nmakarba","contact":"8320497669","lable":"MANISH RATHOD ( 8320497669 )","party_id":"8","ledger_mapper_details":[{"ledger_id":"941","tally_ledger_name_mapper":"Cash","billing_ledger_id":"942","ledger_amount":"3000.00","transaction_type":"CASH","instrument_no":"","instrument_date":"","bank_name":""}],"payment_ref_details":[{"reference_no":"1","amount_received":"3000","bill_total_amount":"3000","sale_invoice_id":"1"}],"bill_payments":[],"billing":[{"selected":"2","billing_shipping_id":"2","address_title":"Home","billing_name":"MANISH RATHOD","contact_no":"8320497669","gst":"QWEASDQWEA12","address":"Ahmedabad makarba"}],"total_pending_amount":0,"narration":"","company_name":"Company-2","branch_name":"Main Location","state":"GUJARAT","city":"AHMEDABAD","country":"India"}]';  
								
								console.log(response);	
								if (response.error != undefined) 
								{
									document.querySelectorAll('.payment_sync')[0].setAttribute('data-send_another','');
								      $('.payment_sync').each(function(){
								       	$(this).data('send_another','');
								      });
		    						 Swal.fire({
							            title: response.error,
							            type: 'error',
							            showConfirmButton:false,
							            timer:1500
								     });
								}
								$.each(response.result ,function(i, paymentDetails) {
									// is_cancelled = '';
									// if (journal_service.billing_name == '<span style="color:red">PURGED</span>') 
									// {
									// 	is_cancelled = '<ISCANCELLED>Yes</ISCANCELLED>';
									// }
								   tally_ledger_name_mapper = escapeHtml(paymentDetails.tally_ledger_name_mapper);
								   total_amount = paymentDetails.total_amount;
								   narration = paymentDetails.narration;
								   voucherNumber = paymentDetails.payment_no;
								   payment_date = paymentDetails.payment_date;
								   payment_date_another_format = paymentDetails.payment_date_another_format;
								   voucher_name = paymentDetails.voucher_name;
								   tally_alter = paymentDetails.tally_alter;
								   godown_name = paymentDetails.branch_name;
								   company_name = paymentDetails.company_name;
								   address = paymentDetails.address;
								   city = paymentDetails.city;
								   state = paymentDetails.state;
								   country = paymentDetails.country;
								   bill_details = paymentDetails.payment_ref_details;
								   payment_details = paymentDetails.ledger_mapper_details;
								//Bill List
								 if(bill_details != '') {
								 	var amount_received= '',reference_no = '';
								 	$.each(bill_details, function (index, bill_detail) {
								 		amount_received = bill_detail.amount_received;
								 		reference_no = bill_detail.reference_no;
								 		ref_name = bill_detail.ref_name;
								 		invoice_date = bill_detail.invoice_date;
								 		cr_dr = bill_detail.cr_dr;
								 		plus_minus = '';
								 		if (cr_dr == 'DR') 
								 		{
								 			plus_minus = '-';
								 		}
								 		if (isNaN(reference_no.charAt(0))) 
								 		{
								 			reference_no = reference_no.charAt(0).toUpperCase() + reference_no.substr(1);
								 		}
								 		res_bill_details += '<BILLALLOCATIONS.LIST> <NAME>'+reference_no+'</NAME> <BILLTYPE>'+ref_name+'</BILLTYPE> <AMOUNT>'+plus_minus+''+amount_received+'</AMOUNT> </BILLALLOCATIONS.LIST>';
								 	});		
								 }

								 //Payment List
								 if(payment_details != '') {
								 	var bank_details = '', bank_name = '',instrument_no = '',instrument_date = '',ledger_amount = '', ledger_name_mapper= '', item_description= '', price_without_tax = '';
								 	$.each(payment_details, function (index, payment_detail) {
								 		instrument_date = payment_detail.instrument_date;
								 		bank_name = payment_detail.bank_name;
								 		instrument_no = payment_detail.instrument_no;
								 		ledger_amount = payment_detail.ledger_amount;
								 		ledger_name_mapper = escapeHtml(payment_detail.tally_ledger_name_mapper);

								 		switch (payment_detail.transaction_type)
								 		{
								 			case 'E-FUND TRANSFER':
								 				bank_details = '<BANKALLOCATIONS.LIST> <DATE>'+instrument_date+'</DATE> <INSTRUMENTDATE>'+instrument_date+'</INSTRUMENTDATE> <TRANSACTIONTYPE>Same Bank Transfer</TRANSACTIONTYPE><BANKNAME>'+bank_name+'</BANKNAME><INSTRUMENTNUMBER>'+instrument_no+'</INSTRUMENTNUMBER><PAYMENTFAVOURING>'+tally_ledger_name_mapper+'</PAYMENTFAVOURING> <PAYMENTMODE>Transacted</PAYMENTMODE> <BANKPARTYNAME>'+tally_ledger_name_mapper+'</BANKPARTYNAME> <AMOUNT>'+ledger_amount+'</AMOUNT> </BANKALLOCATIONS.LIST>';
								 				break;
											case 'CHEQUE':
								 				bank_details = '<BANKALLOCATIONS.LIST> <DATE>'+instrument_date+'</DATE> <INSTRUMENTDATE>'+instrument_date+'</INSTRUMENTDATE> <TRANSACTIONTYPE>Cheque</TRANSACTIONTYPE><BANKNAME>'+bank_name+'</BANKNAME><INSTRUMENTNUMBER>'+instrument_no+'</INSTRUMENTNUMBER><PAYMENTFAVOURING>'+tally_ledger_name_mapper+'</PAYMENTFAVOURING><CHEQUECROSSCOMMENT>A/c Payee</CHEQUECROSSCOMMENT><PAYMENTMODE>Transacted</PAYMENTMODE> <BANKPARTYNAME>'+tally_ledger_name_mapper+'</BANKPARTYNAME> <AMOUNT>-'+ledger_amount+'</AMOUNT> </BANKALLOCATIONS.LIST>';
								 				break;
								 		}
								 		res_payment_details += '<ALLLEDGERENTRIES.LIST> <LEDGERNAME>'+ledger_name_mapper+'</LEDGERNAME> <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE> <ISPARTYLEDGER>Yes</ISPARTYLEDGER> <ISLASTDEEMEDPOSITIVE>No</ISLASTDEEMEDPOSITIVE> <AMOUNT>'+ledger_amount+'</AMOUNT> <VATEXPAMOUNT>'+ledger_amount+'</VATEXPAMOUNT>'+bank_details+'</ALLLEDGERENTRIES.LIST>';
								 	});		
								 }
								if (tally_alter == 0) 
								{
									//CREATE
									res_str = '<ENVELOPE> <HEADER> <TALLYREQUEST>Import Data</TALLYREQUEST> </HEADER><BODY> <IMPORTDATA> <REQUESTDESC> <REPORTNAME>Vouchers</REPORTNAME> <STATICVARIABLES> <SVCURRENTCOMPANY>'+company_name+'</SVCURRENTCOMPANY> </STATICVARIABLES> </REQUESTDESC> <REQUESTDATA> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <VOUCHER VCHTYPE="'+voucher_name+'" ACTION="Create" OBJVIEW="Accounting Voucher View"> <DATE>'+payment_date+'</DATE> <NARRATION>'+escapeHtml(narration)+'</NARRATION> <VOUCHERTYPENAME>'+voucher_name+'</VOUCHERTYPENAME> <VOUCHERNUMBER>'+voucherNumber+'</VOUCHERNUMBER> <PARTYLEDGERNAME>'+tally_ledger_name_mapper+'</PARTYLEDGERNAME> <FBTPAYMENTTYPE>Default</FBTPAYMENTTYPE> <PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW> <EFFECTIVEDATE>'+payment_date+'</EFFECTIVEDATE> <HASCASHFLOW>Yes</HASCASHFLOW> <ISVATDUTYPAID>Yes</ISVATDUTYPAID> <ALLLEDGERENTRIES.LIST> <LEDGERNAME>'+tally_ledger_name_mapper+'</LEDGERNAME> <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE><ISPARTYLEDGER>Yes</ISPARTYLEDGER> <AMOUNT>-'+total_amount+'</AMOUNT> <VATEXPAMOUNT>-'+total_amount+'</VATEXPAMOUNT> '+res_bill_details+' </ALLLEDGERENTRIES.LIST> '+res_payment_details+' </VOUCHER> </TALLYMESSAGE> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <COMPANY> <REMOTECMPINFO.LIST MERGE="Yes"> <REMOTECMPNAME>'+company_name+'</REMOTECMPNAME> <REMOTECMPSTATE>'+state+'</REMOTECMPSTATE> </REMOTECMPINFO.LIST> </COMPANY> </TALLYMESSAGE> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <COMPANY> <REMOTECMPINFO.LIST MERGE="Yes"> <REMOTECMPNAME>'+company_name+'</REMOTECMPNAME> <REMOTECMPSTATE>'+state+'</REMOTECMPSTATE> </REMOTECMPINFO.LIST> </COMPANY> </TALLYMESSAGE> </REQUESTDATA> </IMPORTDATA></BODY> </ENVELOPE>';
								}
								else
								{
									//ALTER
									res_str = '<ENVELOPE> <HEADER> <TALLYREQUEST>Import Data</TALLYREQUEST> </HEADER><BODY> <IMPORTDATA> <REQUESTDESC> <REPORTNAME>Vouchers</REPORTNAME> <STATICVARIABLES> <SVCURRENTCOMPANY>'+company_name+'</SVCURRENTCOMPANY> </STATICVARIABLES> </REQUESTDESC> <REQUESTDATA> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <VOUCHER DATE="'+payment_date_another_format+'" TAGNAME="Voucher Number" TAGVALUE="'+voucherNumber+'" ACTION="Alter" VCHTYPE="'+voucher_name+'"> <DATE>'+payment_date+'</DATE> <NARRATION>'+escapeHtml(narration)+'</NARRATION> <VOUCHERTYPENAME>'+voucher_name+'</VOUCHERTYPENAME> <VOUCHERNUMBER>'+voucherNumber+'</VOUCHERNUMBER> <PARTYLEDGERNAME>'+tally_ledger_name_mapper+'</PARTYLEDGERNAME> <FBTPAYMENTTYPE>Default</FBTPAYMENTTYPE> <PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW> <EFFECTIVEDATE>'+payment_date+'</EFFECTIVEDATE> <HASCASHFLOW>Yes</HASCASHFLOW> <ISVATDUTYPAID>Yes</ISVATDUTYPAID> <ALLLEDGERENTRIES.LIST> <LEDGERNAME>'+tally_ledger_name_mapper+'</LEDGERNAME> <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE><ISPARTYLEDGER>Yes</ISPARTYLEDGER> <AMOUNT>-'+total_amount+'</AMOUNT> <VATEXPAMOUNT>-'+total_amount+'</VATEXPAMOUNT> '+res_bill_details+' </ALLLEDGERENTRIES.LIST> '+res_payment_details+' </VOUCHER> </TALLYMESSAGE> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <COMPANY> <REMOTECMPINFO.LIST MERGE="Yes"> <REMOTECMPNAME>'+company_name+'</REMOTECMPNAME> <REMOTECMPSTATE>'+state+'</REMOTECMPSTATE> </REMOTECMPINFO.LIST> </COMPANY> </TALLYMESSAGE> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <COMPANY> <REMOTECMPINFO.LIST MERGE="Yes"> <REMOTECMPNAME>'+company_name+'</REMOTECMPNAME> <REMOTECMPSTATE>'+state+'</REMOTECMPSTATE> </REMOTECMPINFO.LIST> </COMPANY> </TALLYMESSAGE> </REQUESTDATA> </IMPORTDATA></BODY> </ENVELOPE>';
								}
										
							  	 var http = new XMLHttpRequest();
							    var data = res_str;
							    console.log(data);		    		
							   	http.open('POST', ipAddressTally, false);
								http.onreadystatechange = function() {							   	
								    if(http.readyState == 4 && http.status == 200) {
								   	 var xmlDoc = http.responseXML;
								   	 if(xmlDoc.getElementsByTagName("LINEERROR")[0]!=null || xmlDoc.getElementsByTagName("ALTERED")[0].innerHTML=='0' && xmlDoc.getElementsByTagName("CREATED")[0].innerHTML=='0') {
		    						 var x = xmlDoc.getElementsByTagName("LINEERROR")[0]!=null?xmlDoc.getElementsByTagName("LINEERROR")[0].innerHTML:"UNKNOWN ERROR";
		    						 document.querySelectorAll('.payment_sync')[0].setAttribute('data-send_another','');
								      $('.payment_sync').each(function(){
								       	$(this).data('send_another','');
								      });
		    						 // Swal.fire(x);
		    						//   $.ajax({
										  //    type: 'post',
										  //    url: ipAddress+'v1/001/payment_tally_sync_done',
										  //    data: {payment_id: payment_service.payment_id, status: false, message: x},
										  //    success: function (responseMessage) {
										  //              console.log(responseMessage);
										  //              // location.reload();
										  //    }
										  // });	

		    						 Swal.fire({
							            title: x,
							            type: 'error',
							            showConfirmButton:false,
							            timer:1500
								     });
									} else {								
											object["params"] = {"status":true,'message':"Payment Marked As Sync SuccessFully!"};
											json = JSON.stringify(object);
											 $.ajax({
										     type: 'post',
										    //  url: 	ipAddress+'v1/001/payment_tally_sync_done',
										    //  data: {payment_id: payment_service.payment_id, status: true, message: "Payment SuccessFully Created !"},
											url: tally_sync_url+"Payment/"+payment_service.payment_id,
										// headers:{"Cookie":cookies},
											dataType : "json",
											contentType: "application/json; charset=utf-8",
											data:json,
										     success: function (responseMessage) {
										               console.log(responseMessage);
										               $('#'+btn_id).closest("tr").remove();
										     }
										  });	
											Swal.fire({
									            title: 'Payment SuccessFully Created!',
									            type: 'success',
									            showConfirmButton:false,
									            timer:1500
									      	});	  
										}	 
								    } else {
								    	  if(http.readyState == 4 && http.status == 0) { 
								    	  	document.querySelectorAll('.payment_sync')[0].setAttribute('data-send_another','');
										      $('.payment_sync').each(function(){
										       	$(this).data('send_another','');
										      });
								    	  	Swal.fire({
									            title: 'Please Start Tally !!!',
									            type: 'error',
									            showConfirmButton:false,
									            timer:1500
									      	});
								    	  }
								    }
								}
					  			http.send(data);

							  	});   

							  }, 
							  error: function(error) {
							  	document.querySelectorAll('.payment_sync')[0].setAttribute('data-send_another','');
								      $('.payment_sync').each(function(){
								       	$(this).data('send_another','');
								      });
							  Swal.fire({
					            title: 'Payment Id Not Found!!!',
					            type: 'error',
					            showConfirmButton:false,
					            timer:1500
					      	  });	
							}	
						});	
					});

			  	 });
					document.write("</table>");	
				call_all_sync('#payment_sync_all','.payment_sync');

			}, 
			    error: function(error) {
			    	document.querySelectorAll('.payment_sync')[0].setAttribute('data-send_another','');
				      $('.payment_sync').each(function(){
				       	$(this).data('send_another','');
				      });
			    	Swal.fire({
			            title: 'Api Not Found!!!',
			            type: 'error',
			            showConfirmButton:false,
			            timer:1500
			      	});
				}
		});	
	

	});

	//Journal fetch All
	$('#fetchJournal').on("click", function () {
		var inx= 0;
		Swal.fire({
		     title: 'Loading Journals,Please Wait.'
		});
		Swal.showLoading();
		$.ajax({
			// url: ipAddress_api+"v1/001/fetch_journal_data",
			type: "POST",
			// headers: {"X-Auth-Token": $('#token_auth_key').val()},
			// data: {token_company_id: $('#token_company_id').val()},
			url: get_all_journal_url,
			// headers:{"Cookie":cookies},
			dataType : "json",
			contentType: "application/json; charset=utf-8",
			data:json,
			success: function(response) {
					Swal.close();
					const token_auth_key = $('#token_auth_key').val();
					const token_company_id = $('#token_company_id').val();
					document.write("<script src='jquery-3.3.1.min.js'></script>");
					document.write("<script src='jquery-3.3.1.min.js'></script>");
					document.write("<script src='custom.js'></script>");
					document.write("<script src='sweetalert2.js'></script>");	
					document.write("<style>table {font-family: arial, sans-serif;border-collapse: collapse;width: 100%;}");
					document.write("td, th {border: 1px solid #dddddd; text-align: center;  padding: 8px;}");
					document.write("tr:nth-child(even) {background-color: #dddddd;}</style>");
					
				     document.write("<h1 style=color:blue;text-align:center;>Journal Table</h1><table>");
				     document.write("<tr><th>Id#</th><th>Journal Number</th><th>Journals Id</th><th>ACTION | " +'<button id="journal_sync_all" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Sync All</button>'+ "</th></tr>");

					$.each(response.result, function (index, journal_service) {
					inx++;
					document.write("<tr id='tr_"+inx+"''><td>" + (index+1) + "</td><td>" + journal_service.journal_no + " ("+ journal_service.billing_name +" )(Amount: "+journal_service.amount+")</td><td>" +
					journal_service.journal_id +"</td><td>" +'<button id="clickme_'+inx+'" class="journal_sync" data-send_another="true"  style="background-color: blue;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Add Journal In Tally</button><button id="syncme_'+inx+'" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Mark As Sync</button>'+ "</td></tr>");			
				  $('#syncme_'+inx).on("click", function() {
				 		var btn_id = $(this).attr('id');
						object["params"] = {"status":true,'message':"Journal Marked As Sync SuccessFully!"};
						json = JSON.stringify(object);
				 		$.ajax({
						    type: 'post',
						    // url: 	ipAddress_api+'v1/001/journal_tally_sync_done',
						    // headers: {"X-Auth-Token": token_auth_key},
						    // data: {token_company_id: token_company_id,journal_id: journal_service.journal_id, status: true, message: "Journal Marked As Sync SuccessFully!"},
							url: tally_sync_url+"Journal/"+journal_service.journal_id,
						// headers:{"Cookie":cookies},
							dataType : "json",
							contentType: "application/json; charset=utf-8",
							data:json,
						    success: function (responseMessage) {
						              console.log(responseMessage);
						              $('#'+btn_id).closest("tr").remove();
						    }
						 });	
						Swal.fire({
				            title: 'Journal Marked As Sync SuccessFully!',
				            type: 'success',
				            showConfirmButton:false,
				            timer:1500
				      	});	
				  });
				  $('#clickme_'+inx).on("click", function() {
				 		var btn_id = $(this).attr('id');
				 		
				 		$.ajax({
				 				async: false,
								type: 'post',
								// headers: {"X-Auth-Token": token_auth_key},
								// url: ipAddress_api+'v1/001/fetch_journal',
								// data: {token_company_id: token_company_id,journal_id:journal_service.journal_id},
								url: get_journal_url+journal_service.journal_id,
								dataType : "json",
								contentType: "application/json; charset=utf-8",
								data:json,
								success: function (response) {
								var tally_ledger_name_mapper = '',res_bill_details ='', res_journal_details= '', state = '', total_amount ='', narration = '',reference_no = '', res_str = '', company_name ='', voucherNumber = '', voucher_name ='',journal_date = '',journal_items_details = '',journal_details = '';

								// var response ='[{"journal_id":"1","payment_date":"20190923","payment_no":"1","voucher_id":"29","voucher_name":"Payment","tally_ledger_name_mapper":"MANISH RATHOD \/ GJ01RA8002 \/ 8320497669","total_amount":"3000","party_name":"MANISH RATHOD","c_name":"Manish Rathod","gst":"","address":"Ahmedabad\\nmakarba","contact":"8320497669","lable":"MANISH RATHOD ( 8320497669 )","party_id":"8","ledger_mapper_details":[{"ledger_id":"941","tally_ledger_name_mapper":"Cash","billing_ledger_id":"942","ledger_amount":"3000.00","transaction_type":"CASH","instrument_no":"","instrument_date":"","bank_name":""}],"payment_ref_details":[{"reference_no":"1","amount_received":"3000","bill_total_amount":"3000","sale_invoice_id":"1"}],"bill_payments":[],"billing":[{"selected":"2","billing_shipping_id":"2","address_title":"Home","billing_name":"MANISH RATHOD","contact_no":"8320497669","gst":"QWEASDQWEA12","address":"Ahmedabad makarba"}],"total_pending_amount":0,"narration":"","company_name":"Company-2","branch_name":"Main Location","state":"GUJARAT","city":"AHMEDABAD","country":"India"}]';  
								
								console.log(response);	
								if (response.error != undefined) 
								{
									document.querySelectorAll('.journal_sync')[0].setAttribute('data-send_another','');
								      $('.journal_sync').each(function(){
								       	$(this).data('send_another','');
								      });
		    						 Swal.fire({
							            title: response.error,
							            type: 'error',
							            showConfirmButton:false,
							            timer:1500
								     });
								}
								is_cancelled = '';
								if (journal_service.billing_name == '<span style="color:red">PURGED</span>') 
								{
									is_cancelled = '<ISCANCELLED>Yes</ISCANCELLED>';
									action = 'Cancel';
								}
								else
								{
									action = 'Create';
								}
								$.each(response.result ,function(i, journalDetails) {
								   
								   tally_ledger_name_mapper = escapeHtml(journalDetails.tally_ledger_name_mapper);
								   total_amount = journalDetails.item_amount;
								   narration = journalDetails.narration;
								   voucherNumber = journalDetails.journal_no;
								   journal_date = journalDetails.journal_date;
								   voucher_name = journalDetails.voucher_name;
								   company_name = journalDetails.company_name;
								   state = journalDetails.state;
								   journal_items_details = journalDetails.journal_item;
								
								// alert(journal_date);
								 amount_received = journalDetails.item_amount;
								 if(journalDetails.reference_no!='')
								 {
									 reference_no = '<REFERENCE>'+escapeHtml(journalDetails.reference_no)+'</REFERENCE>';
								 }

								 //Journal item List
								 if(journal_items_details != '') {
								 	var plus_minus = '',ledger_amount = '', ledger_name_mapper= '', ledger_description= '', item_dr_cr = '';
								 	$.each(journal_items_details, function (index, journal_detail) {
										var plus_minus = '';
										var ISDEEMEDPOSITIVE = 'No';
										var ledger_narration = '';
								 		item_dr_cr = journal_detail.item_dr_cr;
								 		ledger_description = journal_detail.ledger_description;
								 		ledger_amount = journal_detail.item_amount;
								 		ledger_name_mapper = escapeHtml(journal_detail.tally_ledger_name_mapper);
										if(ledger_description != '')
										{
											ledger_narration = '<NARRATION>'+escapeHtml(ledger_description)+'</NARRATION>';
										}
								 		if (item_dr_cr == 'DR') 
								 		{
								 			plus_minus = '-';
											ISDEEMEDPOSITIVE = 'Yes';
								 		}

								 		res_journal_details += '<LEDGERENTRIES.LIST> '+ledger_narration+'<LEDGERNAME>'+ledger_name_mapper+'</LEDGERNAME> <ISDEEMEDPOSITIVE>'+ISDEEMEDPOSITIVE+'</ISDEEMEDPOSITIVE> <ISPARTYLEDGER>Yes</ISPARTYLEDGER> <ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE> <AMOUNT>'+plus_minus+''+ledger_amount+'</AMOUNT> <VATEXPAMOUNT>'+plus_minus+''+ledger_amount+'</VATEXPAMOUNT></LEDGERENTRIES.LIST>';
								 	});		
								 }
							
								res_str = '<ENVELOPE> <HEADER> <TALLYREQUEST>Import Data</TALLYREQUEST> </HEADER><BODY> <IMPORTDATA> <REQUESTDESC> <REPORTNAME>Vouchers</REPORTNAME> <STATICVARIABLES> <SVCURRENTCOMPANY>'+company_name+'</SVCURRENTCOMPANY> </STATICVARIABLES> </REQUESTDESC> <REQUESTDATA> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <VOUCHER DATE="'+journal_date+'" TAGNAME="Voucher Number" TAGVALUE="'+voucherNumber+'" ACTION="Alter" VCHTYPE="'+voucher_name+'" OBJVIEW="Accounting Voucher View"> <DATE>'+journal_date+'</DATE> <NARRATION>'+escapeHtml(narration)+'</NARRATION> <VOUCHERTYPENAME>'+voucher_name+'</VOUCHERTYPENAME> '+reference_no+'<VOUCHERNUMBER>'+voucherNumber+'</VOUCHERNUMBER> <FBTPAYMENTTYPE>Default</FBTPAYMENTTYPE> <PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW> <EFFECTIVEDATE>'+journal_date+'</EFFECTIVEDATE>'+is_cancelled+' <HASCASHFLOW>Yes</HASCASHFLOW> <ISVATDUTYPAID>Yes</ISVATDUTYPAID> '+res_journal_details+'  </VOUCHER> </TALLYMESSAGE> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <COMPANY> <REMOTECMPINFO.LIST MERGE="Yes"> <REMOTECMPNAME>'+company_name+'</REMOTECMPNAME> <REMOTECMPSTATE>'+state+'</REMOTECMPSTATE> </REMOTECMPINFO.LIST> </COMPANY> </TALLYMESSAGE> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <COMPANY> <REMOTECMPINFO.LIST MERGE="Yes"> <REMOTECMPNAME>'+company_name+'</REMOTECMPNAME> <REMOTECMPSTATE>'+state+'</REMOTECMPSTATE> </REMOTECMPINFO.LIST> </COMPANY> </TALLYMESSAGE> </REQUESTDATA> </IMPORTDATA></BODY> </ENVELOPE>';
										
							  	var http = new XMLHttpRequest();
							    var data = res_str;
							    console.log(data);		    		
							   	http.open('POST', ipAddressTally, false);
								http.onreadystatechange = function() {							   	
								    if(http.readyState == 4 && http.status == 200) {
								   	 var xmlDoc = http.responseXML;
								   	 if(xmlDoc.getElementsByTagName("LINEERROR")[0]!=null || xmlDoc.getElementsByTagName("ALTERED")[0].innerHTML=='0' && xmlDoc.getElementsByTagName("CREATED")[0].innerHTML=='0') {
		    						 var x = xmlDoc.getElementsByTagName("LINEERROR")[0]!=null?xmlDoc.getElementsByTagName("LINEERROR")[0].innerHTML:"UNKNOWN ERROR";
		    						 document.querySelectorAll('.journal_sync')[0].setAttribute('data-send_another','');
								      $('.journal_sync').each(function(){
								       	$(this).data('send_another','');
								      });
		    						 // Swal.fire(x);
		    						//   $.ajax({
										  //    type: 'post',
										  //    url: ipAddress+'v1/001/journal_tally_sync_done',
										  //    data: {journal_id: journal_service.journal_id, status: false, message: x},
										  //    success: function (responseMessage) {
										  //              console.log(responseMessage);
										  //              // location.reload();
										  //    }
										  // });	

		    						 Swal.fire({
							            title: x,
							            type: 'error',
							            showConfirmButton:false,
							            timer:1500
								     });
									} else {		
											object["params"] = {"status":true,'message':"Journal SuccessFully Created !"};
											json = JSON.stringify(object);						
											 $.ajax({
										     type: 'post',
										    //  headers: {"X-Auth-Token": token_auth_key},
										    //  url: 	ipAddress_api+'v1/001/journal_tally_sync_done',
										    //  data: {token_company_id: token_company_id,journal_id: journal_service.journal_id, status: true, message: "Journal SuccessFully Created !"},
											 url: tally_sync_url+"Journal/"+journal_service.journal_id,
											// headers:{"Cookie":cookies},
											 dataType : "json",
											 contentType: "application/json; charset=utf-8",
											 data:json,
										     success: function (responseMessage) {
										               console.log(responseMessage);
										               $('#'+btn_id).closest("tr").remove();
										     }
										  });	
											Swal.fire({
									            title: 'Journal SuccessFully Created!',
									            type: 'success',
									            showConfirmButton:false,
									            timer:1500
									      	});	  
										}	 
								    } else {
								    	  if(http.readyState == 4 && http.status == 0) { 
								    	  	document.querySelectorAll('.journal_sync')[0].setAttribute('data-send_another','');
										      $('.journal_sync').each(function(){
										       	$(this).data('send_another','');
										      });
								    	  	Swal.fire({
									            title: 'Please Start Tally !!!',
									            type: 'error',
									            showConfirmButton:false,
									            timer:1500
									      	});
								    	  }
								    }
								}
					  			http.send(data);

							  	});   

							  }, 
							  error: function(error) {
							  	document.querySelectorAll('.journal_sync')[0].setAttribute('data-send_another','');
								      $('.journal_sync').each(function(){
								       	$(this).data('send_another','');
								      });
							  Swal.fire({
					            title: 'Journal Id Not Found!!!',
					            type: 'error',
					            showConfirmButton:false,
					            timer:1500
					      	  });	
							}	
						});	
					});

			  	 });
					document.write("</table>");	
				call_all_sync('#journal_sync_all','.journal_sync');

			}, 
			    error: function(error) {
			    	document.querySelectorAll('.journal_sync')[0].setAttribute('data-send_another','');
				      $('.journal_sync').each(function(){
				       	$(this).data('send_another','');
				      });
			    	Swal.fire({
			            title: 'Api Not Found!!!',
			            type: 'error',
			            showConfirmButton:false,
			            timer:1500
			      	});
				}
		});	
	

	});

	//Md Sales
	//Sales Invoice fetch all
	$('#fetchSaleOrder').on("click", function () {
		var inx= 0;
		Swal.fire({
		     title: 'Loading Sale Invoices,Please Wait.'
		});
		Swal.showLoading();
		$.ajax({
			url: get_all_sale_url,
			// headers:{"Cookie":cookies},
			dataType : "json",
			contentType: "application/json; charset=utf-8",
			data:json,
			type: "POST",
			success: function(response) {
					Swal.close();
					document.write("<script src='jquery-3.3.1.min.js'></script>");
					document.write("<script src='custom.js'></script>");
					document.write("<script src='sweetalert2.js'></script>");	
					document.write("<style>table {font-family: arial, sans-serif;border-collapse: collapse;width: 100%;}");
					document.write("td, th {border: 1px solid #dddddd; text-align: center;  padding: 8px;}");
					document.write("tr:nth-child(even) {background-color: #dddddd;}</style>");
					
				     document.write("<h1 style=color:blue;text-align:center;>Sales Invoice Table</h1><table>");
				     document.write("<tr><th>Id#</th><th>Invoice Number</th><th>Sales Id</th><th>ACTION | " +'<button id="sale_sync_all" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Sync All</button>'+ "</th></tr>");

					$.each(response.result, function (index, sale_service) {
					inx++;
					document.write("<tr id='tr_"+inx+"''><td>" + (index+1) + "</td><td>" + sale_service.invoice_no + " ("+ sale_service.billing_name +" )(Amount: "+sale_service.amount+")</td><td>" +
					sale_service.sale_id +"</td><td>" +'<button id="clickme_'+inx+'" class="sale_sync" data-send_another="true" style="background-color: blue;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Add Sales In Tally</button><button id="syncme_'+inx+'" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Mark As Sync</button>'+ "</td></tr>");

				  $('#syncme_'+inx).on("click", function() {
				 		var btn_id = $(this).attr('id');
						object["params"] = {"status":true,'message':"Sale Marked As Sync SuccessFully!"};
						json = JSON.stringify(object);
				 		$.ajax({
						    type: 'post',
						    // url: 	ipAddress+'v1/001/payment_tally_sync_done',
						    // data: {payment_id: payment_service.payment_id, status: true, message: "Payment Marked As Sync SuccessFully!"},
							url: tally_sync_url+"Sale/"+sale_service.sale_id,
						// headers:{"Cookie":cookies},
							dataType : "json",
							contentType: "application/json; charset=utf-8",
							data:json,
						    success: function (responseMessage) {
						              console.log(responseMessage);
						              $('#'+btn_id).closest("tr").remove();
						    }
						 });
						Swal.fire({
				            title: 'Sale Marked As Sync SuccessFully!',
				            type: 'success',
				            showConfirmButton:false,
				            timer:1500
				      	});
				  });
				
					// sale_service.sale_id +"</td><td>" +'<button id="clickme_'+inx+'" style="background-color: blue;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Add Sales In Tally</button>'+'<button id="addReceipt'+inx+'" style="background-color: blue;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Add Receipt In Tally</button>'+ "</td></tr>");			
					// document.getElementById("clickme_"+inx+"").disabled = Boolean(Number(sale_service.tally_sync));

				  // $('#addReceipt'+inx).on("click", function () {
				  // 	var btn_id = $(this).attr('id');
				  // });

				  $('#clickme_'+inx).on("click", function() {
				  	console.log('asdasdadsads');
				 		var btn_id = $(this).attr('id');
				 		
				 		$.ajax({
				 				async: false,
								type: 'post',
								url: get_sale_url+sale_service.sale_id,
								// data: {sale_id:sale_service.sale_id, invoice_no:sale_service.invoice_no},
								dataType : "json",
								contentType: "application/json; charset=utf-8",
								data:json,
								success: function (response) {
								var res_item ='', res_sale_service= '', bill_landing_no = '', delivery_note_date = '', bill_landing_date = '', orderDate = '';
							    var address = '', city = '', state = '', delivery_terms = '', country= '', gst_number ='', destination='';
								var totalAmount ='', bill_of_landing_no ='', despatched_through ='' , despatch_doc_no='',other_reference ='';
							    var cgst = '',igst = '', refrenceNumber = '', narration = '', createDate = '', party_name = '', buyer_name = '', supplier_invoice_no = '';
							    var sgst = '', res_str = '', godown_name= '', company_name ='', item_description= '', discount = '', gst_name = '';
								var voucherNumber = '', contact = '', vehicle_no = '', vehicle_kms = '', motor_vehicle_no='', term_of_payment='', delivery_note_no='', shipping_date='',order_number ='', voucher_type ='';
								var  roundoff_name ='', roundoff_description ='', roundoff_amount= '',  roundoff ='',igst_amount = 0,cgst_amount = 0,sgst_amount = 0,is_cancelled = '',action = '',tally_alter='';

								// var response ='[{"invoice_date":"2019-03-18","invoice_no":"125","sale_id":"120","party_name":"Aman","company_name":"Company-2","branch_name":"Main Location","contact":"40036768","address":"sattelite","state":"Gujarat","city":"Ahmedabad","country":"India","party_id":"1","vehicle_no":"GJ-01-AB1831","sale_total_amount":"7939","sale_amount_without_tax":"5426.07","total_quantity":"30.00","cgst":"868.31","sgst":"868.31","igst":"0.00","roundoff_amount":"0.18","reference_no":"asdqwe","delivery_note_no":"3212","delivery_note_date":"qweasd","despatch_doc_no":"1212","despatched_through":"van","destination":"surat","bill_landing_no":"4453","bill_landing_date":"01-05-2018","term_of_payment":"5 days","other_reference":"no_one","delivery_terms":"10 days","motor_vehicle_no":"GJ01ER1223","narration":"","order_number":"PO-45","orderDate":"12-03-2019","challan_id":"34","challan_number":"45","sale_item":[{"product_id":"14","item_name":"Apollo TL 165/60R14 Amazer 4G Life","item_description":"desc2","psi_id":"142","psi_deleted":"0","quantity_sales":"10.00","uom_id":"1","uom_name":"kgs","price_per_unit_without_tax":"100.00","price":"1000.00","price_without_tax":"1000.00","price_with_tax":"781.25","item_cgst":"109.38","item_sgst":"109.38","item_igst":"0.00","tax_roundoff":"-0.01","discount":"0.00","item_total_amount":"1000.00","item_available_quantity":"4880.00","gst_id":"3","integrated_tax":"GST Sales 28%"},{"product_id":"15","item_name":"65mm Link Lock","item_description":"desc2","psi_id":"143","psi_deleted":"0","quantity_sales":"20.00","uom_id":"3","uom_name":"ltrs","price_per_unit_without_tax":"260.11","price":"5202.20","price_without_tax":"5202.20","price_with_tax":"4644.82","item_cgst":"278.69","item_sgst":"278.69","item_igst":"0.00","tax_roundoff":"0.00","discount":"0.00","item_total_amount":"5202.20","item_available_quantity":"43897.00","gst_id":"4","integrated_tax":"GST Sales 28%"}]}]';  
								// var response1 ='[{"invoice_date":"2019-03-29","invoice_no":"126","sale_id":"121","party_name":"AMAN","company_name":"Company-2","branch_name":"Main Location","contact":"40036768","address":"sattelite","state":"Gujarat","city":"Ahmedabad","country":"India","party_id":"1","vehicle_no":"GJ-01-AB1831","sale_total_amount":"6202.00","sale_amount_without_tax":"4845.47","total_quantity":"30.00","cgst":"678.37","sgst":"678.37","igst":"0.00","roundoff_amount":"-0.21","reference_no":"asdqwe","delivery_note_no":"3212","delivery_note_date":"qweasd","despatch_doc_no":"1212","despatched_through":"van","destination":"surat","bill_landing_no":"4453","bill_landing_date":"01-05-2018","term_of_payment":"5 days","other_reference":"no_one","delivery_terms":"10 days","motor_vehicle_no":"GJ01ER1223","narration":"","order_number":"PO-48","orderDate":"12-03-2019","challan_id":"37","challan_number":"48","sale_item":[{"product_id":"14","item_name":"Apollo TL 165\/60R14 Amazer 4G Life","item_description":"desc2","psi_id":"144","psi_deleted":"0","quantity_sales":"10.00","uom_id":"1","uom_name":"kgs","price_per_unit_without_tax":"100.00","price":"1000.00","price_without_tax":"1000.00","price_with_tax":"781.25","item_cgst":"109.38","item_sgst":"109.38","item_igst":"0.00","tax_roundoff":"-0.01","discount":"0.00","item_total_amount":"1000.00","item_available_quantity":"4869.00","gst_id":"3","integrated_tax":"GST Sales 28%"},{"product_id":"15","item_name":"65mm Link Lock","item_description":"desc2","psi_id":"145","psi_deleted":"0","quantity_sales":"20.00","uom_id":"3","uom_name":"ltrs","price_per_unit_without_tax":"260.11","price":"5202.20","price_without_tax":"5202.20","price_with_tax":"4064.22","item_cgst":"568.99","item_sgst":"568.99","item_igst":"0.00","tax_roundoff":"0.00","discount":"0.00","item_total_amount":"5202.20","item_available_quantity":"43877.00","gst_id":"3","integrated_tax":"GST Sales 28%"}]}]';  
								
								console.log(response.error);	
								if (response.error != undefined) 
								{
									document.querySelectorAll('.sale_sync')[0].setAttribute('data-send_another','');
								      $('.sale_sync').each(function(){
								       	$(this).data('send_another','');
								      });
		    						 Swal.fire({
							            title: response.error,
							            type: 'error',
							            showConfirmButton:false,
							            timer:1500
								     });
								}
								if (sale_service.billing_name == '<span style="color:red">PURGED</span>') 
								{

								}
								if (sale_service.billing_name == '<span style="color:red">PURGED</span>') 
								{
									is_cancelled = '<ISCANCELLED>Yes</ISCANCELLED>';
									action = 'Cancel';
								}
								else
								{
									action = 'Create';
								}
								$.each(response.result ,function(i, salesDetails) {
								   
								   party_name = escapeHtml(salesDetails.party_name);
								   buyer_name = escapeHtml(salesDetails.buyer_name);
								   if (salesDetails.igst > 0) 
								   {
								   	 igst_amount = salesDetails.igst;
								   }
								   if (salesDetails.cgst > 0 && salesDetails.sgst > 0) 
								   {
								   	 cgst_amount = salesDetails.cgst;
								     sgst_amount = salesDetails.sgst;
								   }
								   total_amount = salesDetails.sale_total_amount;
								   narration = salesDetails.narration;
								   voucherNumber = salesDetails.invoice_no;
								   refrenceNumber = salesDetails.invoice_no;
								   godown_name = salesDetails.branch_name;
								   company_name = salesDetails.company_name;
								   contact = salesDetails.contact;
								   address = salesDetails.address;
								   city = salesDetails.city;
								   state = salesDetails.state;
								   delivery_terms = salesDetails.delivery_terms;
								   country = salesDetails.country;
								   term_of_payment = salesDetails.term_of_payment;
								   despatch_doc_no = salesDetails.despatch_doc_no;
								   despatched_through = salesDetails.despatched_through;
								   destination = salesDetails.destination;
								   bill_landing_no = salesDetails.bill_landing_no;
								   vehicle_no = salesDetails.vehicle_no;
								   vehicle_kms = salesDetails.vehicle_kms;
								   motor_vehicle_no = salesDetails.motor_vehicle_no;
								   other_reference = salesDetails.other_reference;
								   delivery_note_date = salesDetails.delivery_note_date;
								   bill_landing_date = salesDetails.bill_landing_date;
								   delivery_note_no = salesDetails.delivery_note_no;
								   order_number = salesDetails.order_number;
								   orderDate = salesDetails.orderDate;
								   roundoff_amount = salesDetails.roundoff_amount;
								   // roundoff_amount = -0.03;
								   roundoff_name = 'ROUND OFF';
								   roundoff_description = '';
								   voucher_type = salesDetails.voucher_type;
								   // gst_sale = salesDetails.gst_sale;
								   createDate = salesDetails.invoice_date;
								   let d = new Date(salesDetails.invoice_date);
								   createDate = d.getFullYear().toString() +
														(d.getMonth() + 1).toString().padStart(2, '0') +
														d.getDate().toString().padStart(2, '0');
								   let s = new Date(salesDetails.invoice_date);
								   let tallyDate = s.getFullYear().toString() +
												s.getDate().toString().padStart(2, '0') +
												(s.getMonth() + 1).toString().padStart(2, '0');

									
								   // alert('tallyDate');
								   // alert(tallyDate);
								   tally_alter = salesDetails.tally_alter;

								   // console.log("invoice Date : "+createDate);
								   // createDate = formatDate(originalDate);  
								  	 // createDate = '02-05-2019';

								   totalAmount += '<LEDGERENTRIES.LIST><LEDGERNAME>'+
								 			   party_name+'</LEDGERNAME> <GSTCLASS/><ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE><ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE><AMOUNT>-'+
								 			   total_amount+'</AMOUNT><BILLALLOCATIONS.LIST><NAME>'+
								 			   voucherNumber+'</NAME><BILLTYPE>New Ref</BILLTYPE><AMOUNT>-'+
								  			   total_amount+'</AMOUNT></BILLALLOCATIONS.LIST></LEDGERENTRIES.LIST>';
								  	if (igst_amount>0) 
								  	{
								  		igst += '<LEDGERENTRIES.LIST><ROUNDTYPE/><LEDGERNAME>IGST</LEDGERNAME><VOUCHERFBTCATEGORY/><GSTCLASS/><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><AMOUNT>'+
								   			igst_amount+'</AMOUNT><VATEXPAMOUNT>'+
								   			igst_amount+'</VATEXPAMOUNT><GSTDUTYAMOUNT>'+
										    igst_amount+'</GSTDUTYAMOUNT></LEDGERENTRIES.LIST>';
								  	}		   
								   else if(cgst_amount > 0 && sgst_amount > 0)
								   {
								   		cgst += '<LEDGERENTRIES.LIST><ROUNDTYPE/><LEDGERNAME>CGST</LEDGERNAME><VOUCHERFBTCATEGORY/><GSTCLASS/><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><AMOUNT>'+
								   			cgst_amount+'</AMOUNT><VATEXPAMOUNT>'+
								   			cgst_amount+'</VATEXPAMOUNT><GSTDUTYAMOUNT>'+
										    cgst_amount+'</GSTDUTYAMOUNT></LEDGERENTRIES.LIST>';
								  
								   		sgst += '<LEDGERENTRIES.LIST><ROUNDTYPE/><LEDGERNAME>SGST</LEDGERNAME><VOUCHERFBTCATEGORY/><GSTCLASS/><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><AMOUNT>'+
								 		   sgst_amount+'</AMOUNT><VATEXPAMOUNT>'+
								   		   sgst_amount+'</VATEXPAMOUNT><GSTDUTYAMOUNT>'+
								   		   sgst_amount+'</GSTDUTYAMOUNT></LEDGERENTRIES.LIST>';
								   }

								   
								   
								   if(salesDetails.roundoff_amount != 0.00) {
									  
								   roundoff += '<LEDGERENTRIES.LIST><LEDGERNAME>'+
								   			roundoff_name+'</LEDGERNAME><GSTCLASS/> <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><LEDGERFROMITEM>No</LEDGERFROMITEM><REMOVEZEROENTRIES>No</REMOVEZEROENTRIES><ISPARTYLEDGER>No</ISPARTYLEDGER><ISLASTDEEMEDPOSITIVE>No</ISLASTDEEMEDPOSITIVE><ISCAPVATTAXALTERED>No</ISCAPVATTAXALTERED><ISCAPVATNOTCLAIMED>No</ISCAPVATNOTCLAIMED><AMOUNT>'+
								            roundoff_amount+'</AMOUNT><VATEXPAMOUNT>'+
								            roundoff_amount+'</VATEXPAMOUNT><UDF:USERDESCRIPTION.LIST DESC="`User Description`" ISLIST="YES" TYPE="String" INDEX="29"><UDF:USERDESCRIPTION DESC="`User Description`">'+
								            roundoff_description+'</UDF:USERDESCRIPTION></UDF:USERDESCRIPTION.LIST></LEDGERENTRIES.LIST>';
								        }    	
						 		
						 			//sales Item Detail	   
									var global_gst_name = 'Retails Sales';
									if (salesDetails.sale_item != '') 
									{	
									      $.each(salesDetails.sale_item, function(index, sales_item) {					
										  itemName = escapeHtml(sales_item.item_name);
									      rate = sales_item.price_per_unit_without_tax;
									      quantity = sales_item.quantity_sales;
									      amount = sales_item.price_without_tax;
									      item_description = escapeHtml(sales_item.item_description);
									      discount = sales_item.discount;
										  if(sales_item.integrated_tax!=false)
										  {
											global_gst_name = 'Retails Sales';
										  }
									      gst_name = sales_item.integrated_tax!=false?sales_item.integrated_tax:global_gst_name;										
										  gst_details = "<ACCOUNTINGALLOCATIONS.LIST><LEDGERNAME>"+
										  gst_name+"</LEDGERNAME><AMOUNT>"+
										  amount+"</AMOUNT></ACCOUNTINGALLOCATIONS.LIST>";
										
										  res_item += "<ALLINVENTORYENTRIES.LIST><BASICUSERDESCRIPTION.LIST TYPE='String'><BASICUSERDESCRIPTION>"+
										  			  item_description+"</BASICUSERDESCRIPTION></BASICUSERDESCRIPTION.LIST><STOCKITEMNAME>"+
													  itemName+"</STOCKITEMNAME><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><ISLASTDEEMEDPOSITIVE>No</ISLASTDEEMEDPOSITIVE><RATE>"+
													  rate+"</RATE><DISCOUNT>"+
													  discount+"</DISCOUNT><AMOUNT>"+
													  amount+"</AMOUNT><ACTUALQTY>"+
													  quantity+"</ACTUALQTY><BILLEDQTY>"+
													  quantity+"</BILLEDQTY><BATCHALLOCATIONS.LIST><GODOWNNAME>"+
													  godown_name+"</GODOWNNAME><DESTINATIONGODOWNNAME>"+
													  godown_name+"</DESTINATIONGODOWNNAME><AMOUNT>"+
													  amount+"</AMOUNT><ACTUALQTY>"+
													  quantity+"</ACTUALQTY><BILLEDQTY>"+
													  quantity+"</BILLEDQTY></BATCHALLOCATIONS.LIST>"+
													  gst_details+"</ALLINVENTORYENTRIES.LIST>";
									});
								}
								//sales service
								 if(salesDetails.sale_service != '') {
								 	var item_name = '', item_total_amount= '', item_description= '', price_without_tax = '';
								 	$.each(salesDetails.sale_service, function (index, sale_service) {
								 		 item_name = sale_service.item_name;
								 		 item_total_amount = sale_service.price_without_tax;
								 		 item_description = sale_service.item_description;
								 		 
								 		res_sale_service += '<LEDGERENTRIES.LIST><OLDAUDITENTRYIDS.LIST TYPE="Number"><OLDAUDITENTRYIDS>-1</OLDAUDITENTRYIDS></OLDAUDITENTRYIDS.LIST><LEDGERNAME>'+
								 						escapeHtml(item_name)+'</LEDGERNAME><GSTCLASS/><ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE><AMOUNT>'+
								 						item_total_amount+'</AMOUNT><VATEXPAMOUNT>'+
								 						item_total_amount+'</VATEXPAMOUNT><UDF:USERDESCRIPTION.LIST DESC="`User Description`" ISLIST="YES" TYPE="String" INDEX="29"><UDF:USERDESCRIPTION DESC="`User Description`">'+
								 						escapeHtml(item_description)+'</UDF:USERDESCRIPTION></UDF:USERDESCRIPTION.LIST></LEDGERENTRIES.LIST>';
								 	});		
								 }
								 var vehicle_no_kms = '';
								 if (vehicle_no != null && vehicle_kms > 0) 
								 {
								 	vehicle_no_kms = vehicle_no+'/ K.M- '+vehicle_kms;
								 }
								 else if(vehicle_no != null && vehicle_kms == 0)
								 {
								 	vehicle_no_kms = vehicle_no;
								 }
								 else if(vehicle_no == null && vehicle_kms > 0)
								 {
								 	vehicle_no_kms = vehicle_kms;
								 }
								var final_address = '';
								var split_address = address.match(/.{1,20}/g);
								if (address != '\n\n\n' && address != '') 
								{
									for (var i = 0; i < split_address.length; i++) 
									{
										final_address += '<BASICBUYERADDRESS>'+escapeHtml(split_address[i])+'</BASICBUYERADDRESS>';
									}
								}
								var contact_no = '';
								if (contact != 0) 
								{
									contact_no = contact;
								}
								
								//MD Sales
			
								// alert(tally_alter);
								if (tally_alter == 0) 
								{
									
									// alert('create')
									//CREATE
									res_str = '<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME><STATICVARIABLES><SVCURRENTCOMPANY>'+
										  company_name+'</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC><REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF"><VOUCHER  ACTION="'+action+'" OBJVIEW="Invoice Voucher View"><BASICBUYERADDRESS.LIST TYPE="String">'+
										  final_address+'<BASICBUYERADDRESS>'+
										  city+'</BASICBUYERADDRESS><BASICBUYERADDRESS>'+
										  vehicle_no_kms+'</BASICBUYERADDRESS><BASICBUYERADDRESS>'+
										  contact_no+'</BASICBUYERADDRESS></BASICBUYERADDRESS.LIST><BASICORDERTERMS.LIST TYPE="String"><BASICORDERTERMS>'+
										  delivery_terms+'</BASICORDERTERMS></BASICORDERTERMS.LIST><OLDAUDITENTRYIDS.LIST TYPE="Number"><OLDAUDITENTRYIDS>-1</OLDAUDITENTRYIDS></OLDAUDITENTRYIDS.LIST><DATE>'+tallyDate+'</DATE><BILLOFLADINGDATE>'+
										  bill_landing_date+'</BILLOFLADINGDATE><STATENAME>'+
										  state+'</STATENAME><NARRATION>'+
										  escapeHtml(narration)+'</NARRATION><COUNTRYOFRESIDENCE>'+
										  country+'</COUNTRYOFRESIDENCE><PARTYGSTIN>'+
										  gst_number+'</PARTYGSTIN><CLASSNAME>DefaultVoucherClass</CLASSNAME><PARTYNAME>'+
										  buyer_name+'</PARTYNAME><VOUCHERTYPENAME>'+
										  voucher_type+'</VOUCHERTYPENAME><REFERENCE>'+
										  refrenceNumber+'</REFERENCE><VOUCHERNUMBER>'+
										  voucherNumber+'</VOUCHERNUMBER><PARTYLEDGERNAME>'+
										  party_name+'</PARTYLEDGERNAME><BASICBASEPARTYNAME>'+
										  party_name+'</BASICBASEPARTYNAME><CSTFORMISSUETYPE/><CSTFORMRECVTYPE/><FBTPAYMENTTYPE>Default</FBTPAYMENTTYPE><PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW><BILLOFLADINGNO>'+
										  bill_of_landing_no+'</BILLOFLADINGNO><PLACEOFSUPPLY>'+
										  state+'</PLACEOFSUPPLY><BASICSHIPPEDBY>'+
										  despatched_through+'</BASICSHIPPEDBY><BASICBUYERNAME>'+
										  buyer_name+'</BASICBUYERNAME><BASICSHIPDOCUMENTNO>'+
										  despatch_doc_no+'</BASICSHIPDOCUMENTNO><BASICFINALDESTINATION>'+
										  destination+'</BASICFINALDESTINATION><BASICORDERREF>'+
										  other_reference+'</BASICORDERREF><BASICSHIPVESSELNO>'+
										  motor_vehicle_no+'</BASICSHIPVESSELNO><BASICDUEDATEOFPYMT>'+
										  term_of_payment+'</BASICDUEDATEOFPYMT><BASICDATETIMEOFINVOICE>'+
										  createDate+'</BASICDATETIMEOFINVOICE><BASICDATETIMEOFREMOVAL>'+
										  createDate+'</BASICDATETIMEOFREMOVAL><VCHGSTCLASS/><CONSIGNEESTATENAME>'+
										  state+'</CONSIGNEESTATENAME><EFFECTIVEDATE>'+
										  tallyDate+'</EFFECTIVEDATE>'+
										  is_cancelled+'<ISINVOICE>Yes</ISINVOICE><HASDISCOUNTS>Yes</HASDISCOUNTS><ISVATDUTYPAID>Yes</ISVATDUTYPAID><INVOICEDELNOTES.LIST><BASICSHIPPINGDATE>'+
										  delivery_note_date+'</BASICSHIPPINGDATE><BASICSHIPDELIVERYNOTE>'+
										  delivery_note_no+'</BASICSHIPDELIVERYNOTE></INVOICEDELNOTES.LIST><INVOICEORDERLIST.LIST><BASICORDERDATE>'+
										  orderDate+'</BASICORDERDATE><BASICPURCHASEORDERNO>'+
										  order_number+'</BASICPURCHASEORDERNO></INVOICEORDERLIST.LIST> '+
										  totalAmount+' '+res_sale_service+' '+igst+' '+cgst+' '+sgst+' '+roundoff+' '+res_item+' </VOUCHER> </TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
										  company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+
										  state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
										  company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+
										  state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';
								}
								else
								{
									//ALTER									
									// alert('alter');
									// alert(tallyDate);
									res_str = '<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME><STATICVARIABLES><SVCURRENTCOMPANY>'+
										  company_name+'</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC><REQUESTDATA><TALLYMESSAGE xmlns:UDF="TallyUDF"><VOUCHER DATE="'+tallyDate+'" TAGNAME="Voucher Number" TAGVALUE="'+voucherNumber+'" ACTION="Alter" VCHTYPE="'+voucher_type+'"><BASICBUYERADDRESS.LIST TYPE="String">'+
										  final_address+'<BASICBUYERADDRESS>'+
										  city+'</BASICBUYERADDRESS><BASICBUYERADDRESS>'+
										  vehicle_no_kms+'</BASICBUYERADDRESS><BASICBUYERADDRESS>'+
										  contact_no+'</BASICBUYERADDRESS></BASICBUYERADDRESS.LIST><BASICORDERTERMS.LIST TYPE="String"><BASICORDERTERMS>'+
										  delivery_terms+'</BASICORDERTERMS></BASICORDERTERMS.LIST><OLDAUDITENTRYIDS.LIST TYPE="Number"><OLDAUDITENTRYIDS>-1</OLDAUDITENTRYIDS></OLDAUDITENTRYIDS.LIST><DATE>'+
										  tallyDate+'</DATE><BILLOFLADINGDATE>'+
										  bill_landing_date+'</BILLOFLADINGDATE><STATENAME>'+
										  state+'</STATENAME><NARRATION>'+
										  escapeHtml(narration)+'</NARRATION><COUNTRYOFRESIDENCE>'+
										  country+'</COUNTRYOFRESIDENCE><PARTYGSTIN>'+
										  gst_number+'</PARTYGSTIN><CLASSNAME>DefaultVoucherClass</CLASSNAME><PARTYNAME>'+
										  buyer_name+'</PARTYNAME><VOUCHERTYPENAME>'+
										  voucher_type+'</VOUCHERTYPENAME><REFERENCE>'+
										  refrenceNumber+'</REFERENCE><VOUCHERNUMBER>'+
										  voucherNumber+'</VOUCHERNUMBER><PARTYLEDGERNAME>'+
										  party_name+'</PARTYLEDGERNAME><BASICBASEPARTYNAME>'+
										  party_name+'</BASICBASEPARTYNAME><CSTFORMISSUETYPE/><CSTFORMRECVTYPE/><FBTPAYMENTTYPE>Default</FBTPAYMENTTYPE><PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW><BILLOFLADINGNO>'+
										  bill_of_landing_no+'</BILLOFLADINGNO><PLACEOFSUPPLY>'+
										  state+'</PLACEOFSUPPLY><BASICSHIPPEDBY>'+
										  despatched_through+'</BASICSHIPPEDBY><BASICBUYERNAME>'+
										  buyer_name+'</BASICBUYERNAME><BASICSHIPDOCUMENTNO>'+
										  despatch_doc_no+'</BASICSHIPDOCUMENTNO><BASICFINALDESTINATION>'+
										  destination+'</BASICFINALDESTINATION><BASICORDERREF>'+
										  other_reference+'</BASICORDERREF><BASICSHIPVESSELNO>'+
										  motor_vehicle_no+'</BASICSHIPVESSELNO><BASICDUEDATEOFPYMT>'+
										  term_of_payment+'</BASICDUEDATEOFPYMT><BASICDATETIMEOFINVOICE>'+
										  tallyDate+'</BASICDATETIMEOFINVOICE><BASICDATETIMEOFREMOVAL>'+
										  tallyDate+'</BASICDATETIMEOFREMOVAL><VCHGSTCLASS/><CONSIGNEESTATENAME>'+
										  state+'</CONSIGNEESTATENAME><EFFECTIVEDATE>'+tallyDate+'</EFFECTIVEDATE>'+
										  is_cancelled+'<ISINVOICE>Yes</ISINVOICE><HASDISCOUNTS>Yes</HASDISCOUNTS><ISVATDUTYPAID>Yes</ISVATDUTYPAID><INVOICEDELNOTES.LIST><BASICSHIPPINGDATE>'+
										  delivery_note_date+'</BASICSHIPPINGDATE><BASICSHIPDELIVERYNOTE>'+
										  delivery_note_no+'</BASICSHIPDELIVERYNOTE></INVOICEDELNOTES.LIST><INVOICEORDERLIST.LIST><BASICORDERDATE>'+
										  orderDate+'</BASICORDERDATE><BASICPURCHASEORDERNO>'+
										  order_number+'</BASICPURCHASEORDERNO></INVOICEORDERLIST.LIST> '+
										  totalAmount+' '+res_sale_service+' '+igst+' '+cgst+' '+sgst+' '+roundoff+' '+res_item+' </VOUCHER> </TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
										  company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+
										  state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE><TALLYMESSAGE xmlns:UDF="TallyUDF"><COMPANY><REMOTECMPINFO.LIST MERGE="Yes"><REMOTECMPNAME>'+
										  company_name+'</REMOTECMPNAME><REMOTECMPSTATE>'+
										  state+'</REMOTECMPSTATE></REMOTECMPINFO.LIST></COMPANY></TALLYMESSAGE></REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';
								}

										
									var http = new XMLHttpRequest();
							    var data = res_str;
							    console.log(data);		    		
							   	http.open('POST', ipAddressTally, false);
								http.onreadystatechange = function() {							   	
								    if(http.readyState == 4 && http.status == 200) {
								   	 var xmlDoc = http.responseXML;
								   	 if(xmlDoc.getElementsByTagName("LINEERROR")[0]!=null || xmlDoc.getElementsByTagName("ALTERED")[0].innerHTML=='0' && xmlDoc.getElementsByTagName("CREATED")[0].innerHTML=='0') {
		    						 var x = xmlDoc.getElementsByTagName("LINEERROR")[0]!=null?xmlDoc.getElementsByTagName("LINEERROR")[0].innerHTML:"UNKNOWN ERROR";
		    						 document.querySelectorAll('.sale_sync')[0].setAttribute('data-send_another','');
								      $('.sale_sync').each(function(){
								       	$(this).data('send_another','');
								      });
		    						 // Swal.fire(x);
		    						//   $.ajax({
										  //    type: 'post',
										  //    url: ipAddress+'v1/001/tally_sync_done',
										  //    data: {sale_id: sale_service.sale_id, status: false, message: x},
										  //    success: function (responseMessage) {
										  //              console.log(responseMessage);
										  //              // location.reload();
										  //    }
										  // });	

		    						 Swal.fire({
							            title: x,
							            type: 'error',
							            showConfirmButton:false,
							            timer:1500
								     });
									} else {			
											object["params"] = {"status":true,'message':"Sales Invoice SuccessFully Created !"};
											json = JSON.stringify(object);					
											 $.ajax({
										     type: 'post',
										    //  url: 	ipAddress+'v1/001/tally_sync_done',
										    //  data: {sale_id: sale_service.sale_id, status: true, message: "Sales Order SuccessFully Created !"},
											url: tally_sync_url+"Sale/"+sale_service.sale_id,
											// headers:{"Cookie":cookies},
											 dataType : "json",
											 contentType: "application/json; charset=utf-8",
											 data:json,
										     success: function (responseMessage) {
										               console.log(responseMessage);
										               $('#'+btn_id).closest("tr").remove();
										     }
										  });	
											Swal.fire({
									            title: 'Sales Order SuccessFully Created!',
									            type: 'success',
									            showConfirmButton:false,
									            timer:1500
									      	});	  
										}	 
								    } else {
								    	  if(http.readyState == 4 && http.status == 0) { 
								    	  	document.querySelectorAll('.sale_sync')[0].setAttribute('data-send_another','');
										      $('.sale_sync').each(function(){
										       	$(this).data('send_another','');
										      });
								    	  	Swal.fire({
									            title: 'Please Start Tally !!!',
									            type: 'error',
									            showConfirmButton:false,
									            timer:1500
									      	});
								    	  }
								    }
								}
					  			http.send(data);

							  	});   

							  }, 
							  error: function(error) {
							  	document.querySelectorAll('.sale_sync')[0].setAttribute('data-send_another','');
						      $('.sale_sync').each(function(){
						       	$(this).data('send_another','');
						      });
							  Swal.fire({
					            title: 'Sale Id Not Found!!!',
					            type: 'error',
					            showConfirmButton:false,
					            timer:1500
					      	  });
							}	
						});	
					});

			  	 });
					document.write("</table>");	
					call_all_sync('#sale_sync_all','.sale_sync');
			}, 
			    error: function(error) {
			    	document.querySelectorAll('.sale_sync')[0].setAttribute('data-send_another','');
				      $('.sale_sync').each(function(){
				       	$(this).data('send_another','');
				      });
			    	Swal.fire({
			            title: 'Api Not Found!!!',
			            type: 'error',
			            showConfirmButton:false,
			            timer:1500
			      	});
				}
		});	
		

	});

	
	//Receipt fetch All
	$('#fetchReceipt').on("click", function () {
		var inx= 0;
		Swal.fire({
		     title: 'Loading Receipts,Please Wait.'
		});
		Swal.showLoading();
		$.ajax({
			// url: ipAddress+"v1/001/fetch_receipt_data",
			// type: "GET",
			url: get_all_receipt_url,
			// headers:{"Cookie":cookies},
			dataType : "json",
			contentType: "application/json; charset=utf-8",
			data:json,
			type: "POST",
			success: function(response) {
					Swal.close();
					document.write("<script src='jquery-3.3.1.min.js'></script>");
					document.write("<script src='custom.js'></script>");
					document.write("<script src='sweetalert2.js'></script>");	
					document.write("<style>table {font-family: arial, sans-serif;border-collapse: collapse;width: 100%;}");
					document.write("td, th {border: 1px solid #dddddd; text-align: center;  padding: 8px;}");
					document.write("tr:nth-child(even) {background-color: #dddddd;}</style>");
					
				     document.write("<h1 style=color:blue;text-align:center;>Receipt Table</h1><table>");
				     document.write("<tr><th>Id#</th><th>Receipt Number</th><th>Receipts Id</th><th>ACTION | " +'<button id="receipt_sync_all" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Sync All</button>'+ "</th></tr>");

					$.each(response.result, function (index, receipt_service) {
					inx++;
					document.write("<tr id='tr_"+inx+"''><td>" + (index+1) + "</td><td>" + receipt_service.receipt_no + " ("+ receipt_service.billing_name +" )(Amount: "+receipt_service.amount+")</td><td>" +
					receipt_service.receipt_id +"</td><td>" +'<button id="clickme_'+inx+'" class="receipt_sync" data-send_another="true" style="background-color: blue;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Add Receipt In Tally</button><button id="syncme_'+inx+'" style="background-color: green;border-radius: 5px;padding: 3px 25px;color:white;box-shadow: none;">Mark As Sync</button>'+ "</td></tr>");			
				  $('#syncme_'+inx).on("click", function() {
				 		var btn_id = $(this).attr('id');
						object["params"] = {"status":true,'message':"Receipt Marked As Sync SuccessFully!"};
						json = JSON.stringify(object);
				 		$.ajax({
						    type: 'post',
						    // url: 	ipAddress+'v1/001/receipt_tally_sync_done',
						    // data: {receipt_id: receipt_service.receipt_id, status: true, message: "Receipt Marked As Sync SuccessFully!"},
							url: tally_sync_url+"Receipt/"+receipt_service.receipt_id,
						// headers:{"Cookie":cookies},
							dataType : "json",
							contentType: "application/json; charset=utf-8",
							data:json,
						    success: function (responseMessage) {
						              console.log(responseMessage);
						              $('#'+btn_id).closest("tr").remove();
						    }
						 });	
						Swal.fire({
				            title: 'Receipt Marked As Sync SuccessFully!',
				            type: 'success',
				            showConfirmButton:false,
				            timer:1500
				      	});	
				  });
				  $('#clickme_'+inx).on("click", function() {
				 		var btn_id = $(this).attr('id');
				 		
				 		$.ajax({
				 				async: false,
								type: 'post',
								// url: ipAddress+'v1/001/fetch_receipt',
								// data: {receipt_id:receipt_service.receipt_id},
								url: get_receipt_url+receipt_service.receipt_id,
								dataType : "json",
								contentType: "application/json; charset=utf-8",
								data:json,
								success: function (response) {
								var tally_ledger_name_mapper = '',res_bill_details ='', res_payment_details= '', address = '', city = '', state = '', country= '', gst_number ='', total_amount ='', narration = '', res_str = '', godown_name= '', company_name ='', voucherNumber = '', voucher_name ='',receipt_date = '',receipt_date_another_format = '',bill_details = '',payment_details = '',tally_alter = '';

								// var response ='[{"receipt_id":"1","receipt_date":"20190923","receipt_no":"1","voucher_id":"29","voucher_name":"Receipt","tally_ledger_name_mapper":"MANISH RATHOD \/ GJ01RA8002 \/ 8320497669","total_amount":"3000","party_name":"MANISH RATHOD","c_name":"Manish Rathod","gst":"","address":"Ahmedabad\\nmakarba","contact":"8320497669","lable":"MANISH RATHOD ( 8320497669 )","party_id":"8","ledger_mapper_details":[{"ledger_id":"941","tally_ledger_name_mapper":"Cash","billing_ledger_id":"942","ledger_amount":"3000.00","transaction_type":"CASH","instrument_no":"","instrument_date":"","bank_name":""}],"receipt_ref_details":[{"reference_no":"1","amount_received":"3000","bill_total_amount":"3000","sale_invoice_id":"1"}],"bill_payments":[],"billing":[{"selected":"2","billing_shipping_id":"2","address_title":"Home","billing_name":"MANISH RATHOD","contact_no":"8320497669","gst":"QWEASDQWEA12","address":"Ahmedabad makarba"}],"total_pending_amount":0,"narration":"","company_name":"Company-2","branch_name":"Main Location","state":"GUJARAT","city":"AHMEDABAD","country":"India"}]';  
								
								console.log(response.result);
								if (response.error != undefined)
								{
									document.querySelectorAll('.receipt_sync')[0].setAttribute('data-send_another','');
								      $('.receipt_sync').each(function(){
								       	$(this).data('send_another','');
								      });
		    						 Swal.fire({
							            title: response.error,
							            type: 'error',
							            showConfirmButton:false,
							            timer:1500
								     });
								}
								$.each(response.result ,function(i, receiptDetails) {
								   
								   tally_ledger_name_mapper = escapeHtml(receiptDetails.tally_ledger_name_mapper);
								   total_amount = receiptDetails.total_amount;
								   narration = receiptDetails.narration;
								   voucherNumber = receiptDetails.receipt_no;
								   receipt_date = receiptDetails.receipt_date;
							   	   voucher_name = receiptDetails.voucher_name;
							   	   tally_alter = receiptDetails.tally_alter;
							   	   receipt_date_another_format = receiptDetails.receipt_date_another_format;
								   godown_name = receiptDetails.branch_name;
								   company_name = receiptDetails.company_name;
								   address = receiptDetails.address;
								   city = receiptDetails.city;
								   state = receiptDetails.state;
								   country = receiptDetails.country;
								   bill_details = receiptDetails.receipt_ref_details;
								   // alert(bill_details);
								   payment_details = receiptDetails.ledger_mapper_details;
								//Bill List
								 if(bill_details != '') {
								 	var amount_received= '',reference_no = '',ref_name = '',invoice_date = '',plus_minus = '',cr_dr = '';
								 	$.each(bill_details, function (index, bill_detail) {
								 		amount_received = bill_detail.amount_received;
								 		reference_no = bill_detail.reference_no;
								 		ref_name = bill_detail.ref_name;
								 		invoice_date = bill_detail.invoice_date;
								 		cr_dr = bill_detail.cr_dr;
								 		plus_minus = '';
								 		if (cr_dr == 'DR') 
								 		{
								 			plus_minus = '-';
								 		}
								 		if (isNaN(reference_no.charAt(0))) 
								 		{
								 			reference_no = reference_no.charAt(0).toUpperCase() + reference_no.substr(1);
								 		}
								 		res_bill_details += '<BILLALLOCATIONS.LIST> <NAME>'+reference_no+'</NAME> <BILLCREDITPERIOD>'+invoice_date+'</BILLCREDITPERIOD> <BILLTYPE>'+ref_name+'</BILLTYPE> <AMOUNT>'+plus_minus+''+amount_received+'</AMOUNT> </BILLALLOCATIONS.LIST>';
								 	});		
								 }

								 //receipt List
								 if(payment_details != '') {
								 	var bank_details = '', bank_name = '',instrument_no = '',instrument_date = '',ledger_amount = '', ledger_name_mapper= '', item_description= '', price_without_tax = '';
								 	$.each(payment_details, function (index, payment_detail) {
								 		instrument_date = payment_detail.instrument_date;
								 		bank_name = payment_detail.bank_name;
								 		instrument_no = payment_detail.instrument_no;
								 		ledger_amount = payment_detail.ledger_amount;
								 		ledger_name_mapper = escapeHtml(payment_detail.tally_ledger_name_mapper);

								 		switch (payment_detail.transaction_type)
								 		{
								 			case 'E-FUND TRANSFER':
								 				bank_details = '<BANKALLOCATIONS.LIST> <DATE>'+instrument_date+'</DATE> <INSTRUMENTDATE>'+instrument_date+'</INSTRUMENTDATE> <TRANSACTIONTYPE>Same Bank Transfer</TRANSACTIONTYPE><BANKNAME>'+bank_name+'</BANKNAME><INSTRUMENTNUMBER>'+instrument_no+'</INSTRUMENTNUMBER><PAYMENTFAVOURING>'+tally_ledger_name_mapper+'</PAYMENTFAVOURING> <PAYMENTMODE>Transacted</PAYMENTMODE> <BANKPARTYNAME>'+tally_ledger_name_mapper+'</BANKPARTYNAME> <AMOUNT>-'+ledger_amount+'</AMOUNT> </BANKALLOCATIONS.LIST>';
								 				break;
											case 'CHEQUE':
								 				bank_details = '<BANKALLOCATIONS.LIST> <DATE>'+instrument_date+'</DATE> <INSTRUMENTDATE>'+instrument_date+'</INSTRUMENTDATE> <TRANSACTIONTYPE>Cheque/DD</TRANSACTIONTYPE><BANKNAME>'+bank_name+'</BANKNAME><INSTRUMENTNUMBER>'+instrument_no+'</INSTRUMENTNUMBER><PAYMENTFAVOURING>'+tally_ledger_name_mapper+'</PAYMENTFAVOURING> <PAYMENTMODE>Transacted</PAYMENTMODE> <BANKPARTYNAME>'+tally_ledger_name_mapper+'</BANKPARTYNAME> <AMOUNT>-'+ledger_amount+'</AMOUNT> </BANKALLOCATIONS.LIST>';
								 				break;
								 		}
								 		res_payment_details += '<ALLLEDGERENTRIES.LIST> <LEDGERNAME>'+ledger_name_mapper+'</LEDGERNAME> <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE> <ISPARTYLEDGER>Yes</ISPARTYLEDGER> <ISLASTDEEMEDPOSITIVE>Yes</ISLASTDEEMEDPOSITIVE> <AMOUNT>-'+ledger_amount+'</AMOUNT> <VATEXPAMOUNT>-'+ledger_amount+'</VATEXPAMOUNT>'+bank_details+'</ALLLEDGERENTRIES.LIST>';
								 	});		
								 }
								 // alert(tally_alter);
								if (tally_alter == 0) 
								{
									//CREATE
									res_str = '<ENVELOPE> <HEADER> <TALLYREQUEST>Import Data</TALLYREQUEST> </HEADER><BODY> <IMPORTDATA> <REQUESTDESC> <REPORTNAME>Vouchers</REPORTNAME> <STATICVARIABLES> <SVCURRENTCOMPANY>'+company_name+'</SVCURRENTCOMPANY> </STATICVARIABLES> </REQUESTDESC> <REQUESTDATA> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <VOUCHER VCHTYPE="'+voucher_name+'" ACTION="Create" OBJVIEW="Accounting Voucher View"> <DATE>20250501</DATE> <NARRATION>'+escapeHtml(narration)+'</NARRATION> <VOUCHERTYPENAME>'+voucher_name+'</VOUCHERTYPENAME> <VOUCHERNUMBER>'+voucherNumber+'</VOUCHERNUMBER> <PARTYLEDGERNAME>'+tally_ledger_name_mapper+'</PARTYLEDGERNAME> <FBTPAYMENTTYPE>Default</FBTPAYMENTTYPE> <PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW> <EFFECTIVEDATE>'+receipt_date+'</EFFECTIVEDATE> <HASCASHFLOW>Yes</HASCASHFLOW> <ISVATDUTYPAID>Yes</ISVATDUTYPAID> <ALLLEDGERENTRIES.LIST> <LEDGERNAME>'+tally_ledger_name_mapper+'</LEDGERNAME> <ISPARTYLEDGER>Yes</ISPARTYLEDGER> <AMOUNT>'+total_amount+'</AMOUNT> <VATEXPAMOUNT>'+total_amount+'</VATEXPAMOUNT> '+res_bill_details+' </ALLLEDGERENTRIES.LIST> '+res_payment_details+' </VOUCHER> </TALLYMESSAGE> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <COMPANY> <REMOTECMPINFO.LIST MERGE="Yes"> <REMOTECMPNAME>'+company_name+'</REMOTECMPNAME> <REMOTECMPSTATE>'+state+'</REMOTECMPSTATE> </REMOTECMPINFO.LIST> </COMPANY> </TALLYMESSAGE> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <COMPANY> <REMOTECMPINFO.LIST MERGE="Yes"> <REMOTECMPNAME>'+company_name+'</REMOTECMPNAME> <REMOTECMPSTATE>'+state+'</REMOTECMPSTATE> </REMOTECMPINFO.LIST> </COMPANY> </TALLYMESSAGE> </REQUESTDATA> </IMPORTDATA></BODY> </ENVELOPE>';
								}
								else
								{
									//ALTER
									res_str = '<ENVELOPE> <HEADER> <TALLYREQUEST>Import Data</TALLYREQUEST> </HEADER><BODY> <IMPORTDATA> <REQUESTDESC> <REPORTNAME>Vouchers</REPORTNAME> <STATICVARIABLES> <SVCURRENTCOMPANY>'+company_name+'</SVCURRENTCOMPANY> </STATICVARIABLES> </REQUESTDESC> <REQUESTDATA> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <VOUCHER DATE="'+receipt_date_another_format+'" TAGNAME="Voucher Number" TAGVALUE="'+voucherNumber+'" ACTION="Alter" VCHTYPE="'+voucher_name+'"> <DATE>'+receipt_date+'</DATE> <NARRATION>'+escapeHtml(narration)+'</NARRATION> <VOUCHERTYPENAME>'+voucher_name+'</VOUCHERTYPENAME> <VOUCHERNUMBER>'+voucherNumber+'</VOUCHERNUMBER> <PARTYLEDGERNAME>'+tally_ledger_name_mapper+'</PARTYLEDGERNAME> <FBTPAYMENTTYPE>Default</FBTPAYMENTTYPE> <PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW> <EFFECTIVEDATE>'+receipt_date+'</EFFECTIVEDATE> <HASCASHFLOW>Yes</HASCASHFLOW> <ISVATDUTYPAID>Yes</ISVATDUTYPAID> <ALLLEDGERENTRIES.LIST> <LEDGERNAME>'+tally_ledger_name_mapper+'</LEDGERNAME> <ISPARTYLEDGER>Yes</ISPARTYLEDGER> <AMOUNT>'+total_amount+'</AMOUNT> <VATEXPAMOUNT>'+total_amount+'</VATEXPAMOUNT> '+res_bill_details+' </ALLLEDGERENTRIES.LIST> '+res_payment_details+' </VOUCHER> </TALLYMESSAGE> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <COMPANY> <REMOTECMPINFO.LIST MERGE="Yes"> <REMOTECMPNAME>'+company_name+'</REMOTECMPNAME> <REMOTECMPSTATE>'+state+'</REMOTECMPSTATE> </REMOTECMPINFO.LIST> </COMPANY> </TALLYMESSAGE> <TALLYMESSAGE xmlns:UDF="TallyUDF"> <COMPANY> <REMOTECMPINFO.LIST MERGE="Yes"> <REMOTECMPNAME>'+company_name+'</REMOTECMPNAME> <REMOTECMPSTATE>'+state+'</REMOTECMPSTATE> </REMOTECMPINFO.LIST> </COMPANY> </TALLYMESSAGE> </REQUESTDATA> </IMPORTDATA></BODY> </ENVELOPE>';
								}
										
							  	 var http = new XMLHttpRequest();
							    var data = res_str;
							    console.log(data);		    		
							   	http.open('POST', ipAddressTally, false);
								http.onreadystatechange = function() {							   	
								    if(http.readyState == 4 && http.status == 200) {
								   	 var xmlDoc = http.responseXML;
								   	 if(xmlDoc.getElementsByTagName("LINEERROR")[0]!=null || xmlDoc.getElementsByTagName("ALTERED")[0].innerHTML=='0' && xmlDoc.getElementsByTagName("CREATED")[0].innerHTML=='0') {
		    						 var x = xmlDoc.getElementsByTagName("LINEERROR")[0]!=null?xmlDoc.getElementsByTagName("LINEERROR")[0].innerHTML:"UNKNOWN ERROR";
		    						 document.querySelectorAll('.receipt_sync')[0].setAttribute('data-send_another','');
								      $('.receipt_sync').each(function(){
								       	$(this).data('send_another','');
								      });
		    						 // Swal.fire(x);
		    						//   $.ajax({
										  //    type: 'post',
										  //    url: ipAddress+'v1/001/receipt_tally_sync_done',
										  //    data: {receipt_id: receipt_service.receipt_id, status: false, message: x},
										  //    success: function (responseMessage) {
										  //              console.log(responseMessage);
										  //              // location.reload();
										  //    }
										  // });	

		    						 Swal.fire({
							            title: x,
							            type: 'error',
							            showConfirmButton:false,
							            timer:1500
								     });
									} else {								
											object["params"] = {"status":true,'message':"Receipt SuccessFully Created !"};
											json = JSON.stringify(object);
											 $.ajax({
										     type: 'post',
										    //  url: 	ipAddress+'v1/001/receipt_tally_sync_done',
										    //  data: {receipt_id: receipt_service.receipt_id, status: true, message: "Receipt SuccessFully Created !"},
											url: tally_sync_url+"Receipt/"+receipt_service.receipt_id,
										// headers:{"Cookie":cookies},
											dataType : "json",
											contentType: "application/json; charset=utf-8",
											data:json,
										     success: function (responseMessage) {
										               console.log(responseMessage);
										               $('#'+btn_id).closest("tr").remove();
										     }
										  });	
											Swal.fire({
									            title: 'Receipt SuccessFully Created!',
									            type: 'success',
									            showConfirmButton:false,
									            timer:1500
									      	});	  
										}	 
								    } else {
								    	  if(http.readyState == 4 && http.status == 0) { 
								    	  	document.querySelectorAll('.receipt_sync')[0].setAttribute('data-send_another','');
										      $('.receipt_sync').each(function(){
										       	$(this).data('send_another','');
										      });
								    	  	Swal.fire({
									            title: 'Please Start Tally !!!',
									            type: 'error',
									            showConfirmButton:false,
									            timer:1500
									      	});
								    	  }
								    }
								}
					  			http.send(data);

							  	});   

							  }, 
							  error: function(error) {
							  	document.querySelectorAll('.receipt_sync')[0].setAttribute('data-send_another','');
						      $('.receipt_sync').each(function(){
						       	$(this).data('send_another','');
						      });
							  Swal.fire({
					            title: 'Receipt Id Not Found!!!',
					            type: 'error',
					            showConfirmButton:false,
					            timer:1500
					      	  });	
							}	
						});	
					});

			  	 });
					document.write("</table>");	
				call_all_sync('#receipt_sync_all','.receipt_sync');

			}, 
			    error: function(error) {
			    	document.querySelectorAll('.receipt_sync')[0].setAttribute('data-send_another','');
				      $('.receipt_sync').each(function(){
				       	$(this).data('send_another','');
				      });
			    	Swal.fire({
			            title: 'Api Not Found!!!',
			            type: 'error',
			            showConfirmButton:false,
			            timer:1500
			      	});
				}
		});	
		

	});
}