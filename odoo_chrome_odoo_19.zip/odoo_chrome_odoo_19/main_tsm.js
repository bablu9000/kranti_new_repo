 function formatDate(date) {
  var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
 
  if (month.length < 2 ) month = '0' + month;
  if (day.length < 2) day = '0' + day;
 
  return [day,month,year].join('-');
 }
 
 // this function converts JSON into string to be entered into localStorage
function AddToLocalStorage(data) {
  if (typeof data != "string") {data = JSON.stringify(data);}
  return data;
}

// this function gets string from localStorage and converts it into JSON
function GetFromLocalStorage(key) {
  return JSON.parse(localStorage.getItem(key));
}
 $(function() {

      var ipAddressTally = 'http://localhost:9000/';
    // var ipAddressTally = 'http://43.227.184.153:8005/';

     $('#buttons').html('');
     var modal = document.getElementById('id01');
	 $('#user').on('change',function(){
		 updateLoginDetails();
	 });
     $('.login').on('click',function(){
         $('#id01').css('display','block');
     });
     $('.close').on('click',function(){
         $('#id01').css('display','none');
     });
     // When the user clicks anywhere outside of the modal, close it
     window.onclick = function(event) {
         if (event.target == modal) {
             modal.style.display = "none";
         }
     }
     var myData = GetFromLocalStorage("added-items");

     if (myData != null) {
      $('#mainpage').remove();
      $('#buttons').append('<button class="button" id="fetchProducts">FetchAllProducts</button><button class="button fectAllSundry" data-invoice_type="Sale">Sundry Debtors</button><button class="button fectAllSundry" data-invoice_type="Purchase">Sundry Creditors</button><button class="button" id="fetchSaleOrder">FetchAllSalesInvoice</button><button class="button" id="fetchReceipt">FetchAllReceipt</button><button class="button" id="fetchPurchaseInvoice">FetchAllPurchaseInvoice</button><button class="button" id="fetchPayment">FetchAllPayment</button><button class="button" id="fetchJournal">FetchAllJournal</button><button class="button" id="btn_logout">Logout</button><select id="company" name="company" style=" padding: 9px; float: right; margin-top: 3px; margin-right: 3%; color: green; "></select><div id = "stage"></div>');
	  // <button class="button" id="fetchJournal">FetchAllJournal</button>
      
      chrome.storage.sync.get(['session_id'], function(result) {
          console.log(result.session_id);          
        });     
      custom(null,ipAddressTally,null);
    }
    
 
     /* Edit data */
     $("#xin-form").submit(function(e){
       var fd = new FormData(this);
       var obj = $(this), action = obj.attr('name');
       var object = {};
       var params_object = {};
       fd.forEach((value, key) => object[key] = value);
       params_object['params'] = object;
      //  console.log(params_object);
        var json = JSON.stringify(params_object);
       e.preventDefault();
       $('.save').prop('disabled', true);


       $.ajax({
         url: $('#server_url').val()+'/auth/',
         type: "POST",
         dataType : "json",
         contentType: "application/json; charset=utf-8",
         data: json,
         xhrFields: { withCredentials: true },
         // headers: {
          // "Access-Control-Allow-Origin": "*",
          // "Access-Control-Expose-Headers": "*",
        // },
     
         success: function(JSON,textStatus, jqXHR)
         {
			console.log("JSON:", JSON);

			console.log(
			"Response Headers:",
			jqXHR.getAllResponseHeaders()
			);

			console.log(
			"Set-Cookie:",
			jqXHR.getResponseHeader("Set-Cookie")
			);
            // jqXHR.setRequestHeader("Access-Control-Expose-Headers", "Set-Cookie");
            var cookies = jqXHR.getAllResponseHeaders();
            console.log(textStatus);
            console.log(jqXHR);
            console.log(cookies);
           if (JSON.error) {
             Swal.fire({
                 title: JSON.error.message,
                 type: 'error',
                 showConfirmButton:false,
                 timer:1500
               });
           } else {
             Swal.fire({
                 title: "Welcome "+JSON.result.name,
                 type: 'success',
                 showConfirmButton:false,
                 timer:1500
               });
             $('#id01').css('display','none');
             $('#mainpage').remove();
             $('#buttons').append('<button class="button" id="fetchProducts">FetchAllProducts</button><button class="button fectAllSundry" data-invoice_type="Sale">Sundry Debtors</button><button class="button fectAllSundry" data-invoice_type="Purchase">Sundry Creditors</button><button class="button" id="fetchSaleOrder">FetchAllSalesInvoice</button><button class="button" id="fetchReceipt">FetchAllReceipt</button><button class="button" id="fetchPurchaseInvoice">FetchAllPurchaseInvoice</button><button class="button" id="fetchPayment">FetchAllPayment</button><button class="button" id="fetchJournal">FetchAllJournal</button><button class="button" id="btn_logout">Logout</button><div id = "stage"></div>');

             localStorage.setItem('added-items', AddToLocalStorage(JSON.result));
              
             var myData = GetFromLocalStorage("added-items");
            //  const baseurl = myData['web.base.url'].split(':');
             var vars = myData['web.base.url'];
             var arrVars = vars.split("://");
            //  console.log(arrVars)
             var firstVar = arrVars.shift();
             var restVar = arrVars.join("://");
             var arrVars = restVar.split(":");
             var lastVar = arrVars.pop();
             var restVar = arrVars.join(":");
             chrome.storage.sync.set({'base_url':restVar}, function() {
              console.log('Value is set to ' + restVar);
            });
            console.log(myData)
            console.log(chrome.cookies.getAllCookieStores())
            location.reload()
            
 
           }
         },
        error: function(xhr, status, error)
		{
		   console.log("XHR:", xhr);
		   console.log("STATUS:", status);
		   console.log("ERROR:", error);

		   console.log("Response:", xhr.responseText);

		  Swal.fire({
             title: "Invalid Server URL!",
             type: 'error',
             showConfirmButton:false,
             timer:1500
             });
		}         
        }).done(function(){
          custom(null,ipAddressTally,null);
        });
     });
     
     
     
 
 
 });