 // this function converts JSON into string to be entered into localStorage
//  function AddToLocalStorage(data) {
//   if (typeof data != "string") {data = JSON.stringify(data);}
//   return data;
// }
// chrome.action.onClicked.addListener(tab => {
//   // Send a message to the active tab
//   chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
//     var activeTab = tabs[0];
//     chrome.tabs.sendMessage(activeTab.id, {"message": "clicked_browser_action"});
//   });
// });
// chrome.cookies.getAll({
//   domain: chrome.runtime.getURL("popup_tsm.html")
// }, function(cookies) {
//   console.log(cookies);
  
// });
chrome.cookies.onChanged.addListener(function(e){
  // console.log(e.domain);
  chrome.storage.sync.get(['base_url'], function(result) {
    // console.log('result');
    // console.log(e.cookie.domain);
    // console.log(result);
    // console.log(GetFromChromeLocalStorage(result.cookies));
    if(e.cookie.domain==result.base_url && e.cause=="explicit" && e.cookie)
    {
      console.log('changed cookies');
      console.log(e);
      var name = e.cookie.name;
      var value = e.cookie.value;
      // localStorage.setItem('cookies', AddToLocalStorage({name:name,value:value}));
      // console.log(chrome.storage);
      if(name=='session_id')
      {
        chrome.storage.sync.set({'session_id':value}, function() {
          console.log('Value is set to ' + name + ' '+ value);
        });
      }
  
      // var domain = 'http://'+e.cookie.domain;
      // chrome.cookies.set({url:domain,name:value});
      // document.cookies = e.cookie;
    }
  });
});
chrome.action.onClicked.addListener(function(tab) {
  chrome.tabs.create({url:chrome.runtime.getURL("popup_tsm.html")});
  // console.log(tab);
  // const tab_id = tab.id
  // chrome.tabs.get(tab_id,function(e){
 
    
  // })
  // console.log("click event captured in current webpage");
});

// chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
//   if (request.type == "click_event") {
//     console.log("click event captured in current webpage");
//     chrome.tabs.create({url:chrome.extension.getURL("popup_tsm.html")});
//     // Call the callback passed to chrome.action.onClicked
//   }
// });
